// src/pages/TasksPage.tsx
// NOMINAL CMMS — Systém úkolů (Work Orders)

import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuthContext } from '../context/AuthContext';
import { UserBadge, StatusBadge, Breadcrumb } from '../components/ui';
import { 
  Plus, Filter, Search, Clock, AlertTriangle, CheckCircle2, 
  Play, Pause, ChevronRight, Calendar, MapPin, Wrench,
  X, Send, User, Flag
} from 'lucide-react';

// ═══════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════

type TaskStatus = 'backlog' | 'planned' | 'in_progress' | 'paused' | 'completed' | 'cancelled';
type TaskPriority = 'P1' | 'P2' | 'P3' | 'P4';
type TaskType = 'corrective' | 'preventive' | 'inspection' | 'improvement';

interface Task {
  id: string;
  code: string;
  title: string;
  description?: string;
  type: TaskType;
  status: TaskStatus;
  priority: TaskPriority;
  assetId?: string;
  assetName?: string;
  assigneeId?: string;
  assigneeName?: string;
  assigneeColor?: string;
  createdById: string;
  createdByName: string;
  createdAt: Date;
  plannedDate?: string;
  dueDate?: string;
  startedAt?: Date;
  completedAt?: Date;
  estimatedMinutes?: number;
  actualMinutes?: number;
}

// ═══════════════════════════════════════════════════════════════════
// CONFIG
// ═══════════════════════════════════════════════════════════════════

const STATUS_CONFIG: Record<TaskStatus, { label: string; color: string; icon: typeof Clock }> = {
  backlog: { label: 'Backlog', color: 'bg-slate-400', icon: Clock },
  planned: { label: 'Naplánováno', color: 'bg-blue-500', icon: Calendar },
  in_progress: { label: 'Probíhá', color: 'bg-amber-500', icon: Play },
  paused: { label: 'Pozastaveno', color: 'bg-orange-500', icon: Pause },
  completed: { label: 'Dokončeno', color: 'bg-emerald-500', icon: CheckCircle2 },
  cancelled: { label: 'Zrušeno', color: 'bg-red-400', icon: X },
};

const PRIORITY_CONFIG: Record<TaskPriority, { label: string; color: string; description: string }> = {
  P1: { label: 'P1', color: 'bg-red-600', description: 'Havárie - ihned' },
  P2: { label: 'P2', color: 'bg-orange-500', description: 'Tento týden' },
  P3: { label: 'P3', color: 'bg-blue-500', description: 'Plánovaná údržba' },
  P4: { label: 'P4', color: 'bg-slate-400', description: 'Nápad/zlepšení' },
};

const TYPE_CONFIG: Record<TaskType, { label: string; icon: string }> = {
  corrective: { label: 'Oprava', icon: '🔧' },
  preventive: { label: 'Preventivní', icon: '🛡️' },
  inspection: { label: 'Kontrola', icon: '🔍' },
  improvement: { label: 'Zlepšení', icon: '💡' },
};

// ═══════════════════════════════════════════════════════════════════
// MOCK DATA
// ═══════════════════════════════════════════════════════════════════

const MOCK_TASKS: Task[] = [
  {
    id: 't1', code: 'WO-2026-001', title: 'Výměna ložiska na Extruderu 1',
    description: 'Hlučné ložisko, nutná výměna SKF 6205',
    type: 'corrective', status: 'in_progress', priority: 'P1',
    assetId: 'ext1', assetName: 'Extruder 1',
    assigneeId: 'u3', assigneeName: 'Vilém', assigneeColor: '#16a34a',
    createdById: 'u5', createdByName: 'Zdeněk',
    createdAt: new Date('2026-02-12T08:00:00'),
    estimatedMinutes: 120, actualMinutes: 45,
  },
  {
    id: 't2', code: 'WO-2026-002', title: 'Kontrola oleje KGJ',
    type: 'preventive', status: 'planned', priority: 'P3',
    assetId: 'kgj1', assetName: 'Kogenerační jednotka',
    assigneeId: 'u3', assigneeName: 'Vilém', assigneeColor: '#16a34a',
    createdById: 'u3', createdByName: 'Vilém',
    createdAt: new Date('2026-02-10'),
    plannedDate: '2026-02-14',
    estimatedMinutes: 30,
  },
  {
    id: 't3', code: 'WO-2026-003', title: 'Balička Karel - zasekávání fólie',
    description: 'Fólie se trhá při vysoké rychlosti',
    type: 'corrective', status: 'backlog', priority: 'P2',
    assetId: 'pack1', assetName: 'Balička Karel',
    createdById: 'u6', createdByName: 'Operátor',
    createdAt: new Date('2026-02-11'),
  },
  {
    id: 't4', code: 'WO-2026-004', title: 'Revize kompresorů',
    type: 'inspection', status: 'planned', priority: 'P3',
    assetId: 'comp1', assetName: 'Kompresor 1',
    assigneeId: 'u5', assigneeName: 'Zdeněk', assigneeColor: '#64748b',
    createdById: 'u4', createdByName: 'Pavla',
    createdAt: new Date('2026-02-08'),
    plannedDate: '2026-02-15',
    estimatedMinutes: 60,
  },
  {
    id: 't5', code: 'WO-2026-005', title: 'Instalace senzoru teploty',
    description: 'Nápad od Milana - monitoring teploty v míchacím centru',
    type: 'improvement', status: 'backlog', priority: 'P4',
    createdById: 'u1', createdByName: 'Milan',
    createdAt: new Date('2026-02-05'),
  },
  {
    id: 't6', code: 'WO-2026-006', title: 'Oprava úniku oleje',
    type: 'corrective', status: 'completed', priority: 'P2',
    assetId: 'ext2', assetName: 'Extruder 2',
    assigneeId: 'u3', assigneeName: 'Vilém', assigneeColor: '#16a34a',
    createdById: 'u5', createdByName: 'Zdeněk',
    createdAt: new Date('2026-02-09'),
    completedAt: new Date('2026-02-11'),
    estimatedMinutes: 90, actualMinutes: 75,
  },
];

// ═══════════════════════════════════════════════════════════════════
// COMPONENT
// ═══════════════════════════════════════════════════════════════════

export default function TasksPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { hasPermission, isReadOnly, user, roleMeta } = useAuthContext();

  // State
  const [tasks, setTasks] = useState<Task[]>(MOCK_TASKS);
  const [filterStatus, setFilterStatus] = useState<TaskStatus | 'all'>('all');
  const [filterPriority, setFilterPriority] = useState<TaskPriority | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [showNewTaskModal, setShowNewTaskModal] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  // Permissions
  const canCreate = hasPermission('wo.create');
  const canAssign = hasPermission('wo.assign');
  const canApprove = hasPermission('wo.approve');

  // Check URL params for new task
  useEffect(() => {
    if (searchParams.get('new') === '1' || searchParams.get('newIssue')) {
      setShowNewTaskModal(true);
    }
  }, [searchParams]);

  // ─────────────────────────────────────────────────────────────────
  // FILTERING
  // ─────────────────────────────────────────────────────────────────

  const filteredTasks = tasks.filter(task => {
    if (filterStatus !== 'all' && task.status !== filterStatus) return false;
    if (filterPriority !== 'all' && task.priority !== filterPriority) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      if (!task.title.toLowerCase().includes(q) && 
          !task.code.toLowerCase().includes(q) &&
          !(task.assetName?.toLowerCase().includes(q))) return false;
    }
    return true;
  });

  // Group by status
  const tasksByStatus = {
    active: filteredTasks.filter(t => ['in_progress', 'paused'].includes(t.status)),
    planned: filteredTasks.filter(t => t.status === 'planned'),
    backlog: filteredTasks.filter(t => t.status === 'backlog'),
    completed: filteredTasks.filter(t => ['completed', 'cancelled'].includes(t.status)),
  };

  // Stats
  const stats = {
    total: tasks.length,
    active: tasks.filter(t => t.status === 'in_progress').length,
    p1: tasks.filter(t => t.priority === 'P1' && !['completed', 'cancelled'].includes(t.status)).length,
    thisWeek: tasks.filter(t => t.status === 'planned').length,
  };

  // ─────────────────────────────────────────────────────────────────
  // ACTIONS
  // ─────────────────────────────────────────────────────────────────

  const handleStartTask = (taskId: string) => {
    setTasks(prev => prev.map(t => 
      t.id === taskId ? { ...t, status: 'in_progress' as TaskStatus, startedAt: new Date() } : t
    ));
  };

  const handleCompleteTask = (taskId: string) => {
    setTasks(prev => prev.map(t => 
      t.id === taskId ? { ...t, status: 'completed' as TaskStatus, completedAt: new Date() } : t
    ));
  };

  // ─────────────────────────────────────────────────────────────────
  // RENDER
  // ─────────────────────────────────────────────────────────────────

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      
      {/* Header */}
      <div className="bg-white border-b px-4 py-4">
        <Breadcrumb items={[
          { label: 'Dashboard', onClick: () => navigate('/') },
          { label: 'Úkoly' },
        ]} />
        
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-slate-800">Work Orders</h1>
          {canCreate && (
            <button 
              onClick={() => setShowNewTaskModal(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium flex items-center gap-2 hover:bg-blue-700"
            >
              <Plus className="w-5 h-5" />
              <span className="hidden sm:inline">Nový úkol</span>
            </button>
          )}
        </div>
      </div>

      <div className="p-4 space-y-4">
        
        {/* Stats */}
        <div className="grid grid-cols-4 gap-2">
          <StatBox label="Celkem" value={stats.total} />
          <StatBox label="Aktivní" value={stats.active} color="text-amber-600" />
          <StatBox label="P1 🔴" value={stats.p1} color="text-red-600" pulse={stats.p1 > 0} />
          <StatBox label="Tento týden" value={stats.thisWeek} color="text-blue-600" />
        </div>

        {/* Search & Filters */}
        <div className="flex gap-2">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Hledat úkol..."
              className="w-full pl-10 pr-4 py-2 border rounded-xl focus:border-blue-500 outline-none"
            />
          </div>
          <button className="p-2 border rounded-xl hover:bg-slate-50">
            <Filter className="w-5 h-5 text-slate-500" />
          </button>
        </div>

        {/* Priority Filter */}
        <div className="flex gap-2 overflow-x-auto pb-1">
          <FilterChip 
            label="Vše" 
            active={filterPriority === 'all'} 
            onClick={() => setFilterPriority('all')} 
          />
          {Object.entries(PRIORITY_CONFIG).map(([key, cfg]) => (
            <FilterChip 
              key={key}
              label={cfg.label}
              color={cfg.color}
              active={filterPriority === key}
              onClick={() => setFilterPriority(key as TaskPriority)}
            />
          ))}
        </div>

        {/* Active Tasks */}
        {tasksByStatus.active.length > 0 && (
          <TaskSection title="🔥 Probíhající" tasks={tasksByStatus.active} onSelect={setSelectedTask} />
        )}

        {/* Planned */}
        {tasksByStatus.planned.length > 0 && (
          <TaskSection title="📅 Naplánováno" tasks={tasksByStatus.planned} onSelect={setSelectedTask} />
        )}

        {/* Backlog */}
        {tasksByStatus.backlog.length > 0 && (
          <TaskSection title="📋 Backlog" tasks={tasksByStatus.backlog} onSelect={setSelectedTask} />
        )}

        {/* Completed */}
        {tasksByStatus.completed.length > 0 && (
          <TaskSection 
            title="✅ Dokončené" 
            tasks={tasksByStatus.completed} 
            onSelect={setSelectedTask}
            collapsed 
          />
        )}

        {/* Empty state */}
        {filteredTasks.length === 0 && (
          <div className="text-center py-12">
            <p className="text-4xl mb-4">📭</p>
            <h3 className="text-lg font-bold text-slate-800 mb-2">Žádné úkoly</h3>
            <p className="text-slate-500">Změňte filtr nebo vytvořte nový úkol</p>
          </div>
        )}
      </div>

      {/* Task Detail Modal */}
      {selectedTask && (
        <TaskDetailModal 
          task={selectedTask} 
          onClose={() => setSelectedTask(null)}
          onStart={() => { handleStartTask(selectedTask.id); setSelectedTask(null); }}
          onComplete={() => { handleCompleteTask(selectedTask.id); setSelectedTask(null); }}
          canAssign={canAssign}
        />
      )}

      {/* New Task Modal */}
      {showNewTaskModal && (
        <NewTaskModal 
          onClose={() => setShowNewTaskModal(false)}
          onCreate={(task) => {
            setTasks(prev => [task, ...prev]);
            setShowNewTaskModal(false);
          }}
          user={user}
          roleMeta={roleMeta}
          assetId={searchParams.get('newIssue') || undefined}
        />
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// SUB-COMPONENTS
// ═══════════════════════════════════════════════════════════════════

function StatBox({ label, value, color = 'text-slate-800', pulse = false }: { 
  label: string; value: number; color?: string; pulse?: boolean;
}) {
  return (
    <div className={`bg-white p-3 rounded-xl border text-center ${pulse ? 'animate-pulse' : ''}`}>
      <div className={`text-2xl font-bold ${color}`}>{value}</div>
      <div className="text-xs text-slate-500">{label}</div>
    </div>
  );
}

function FilterChip({ label, active, onClick, color }: { 
  label: string; active: boolean; onClick: () => void; color?: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition ${
        active ? 'bg-slate-800 text-white' : 'bg-white border text-slate-600 hover:border-slate-400'
      }`}
    >
      {color && <span className={`inline-block w-2 h-2 rounded-full ${color} mr-1.5`} />}
      {label}
    </button>
  );
}

function TaskSection({ title, tasks, onSelect, collapsed = false }: {
  title: string; tasks: Task[]; onSelect: (task: Task) => void; collapsed?: boolean;
}) {
  const [isCollapsed, setIsCollapsed] = useState(collapsed);

  return (
    <div className="bg-white rounded-xl border overflow-hidden">
      <button 
        onClick={() => setIsCollapsed(!isCollapsed)}
        className="w-full p-4 flex items-center justify-between bg-slate-50 border-b"
      >
        <span className="font-bold text-slate-800">{title}</span>
        <span className="text-sm text-slate-500">{tasks.length} úkolů</span>
      </button>
      
      {!isCollapsed && (
        <div className="divide-y">
          {tasks.map(task => (
            <TaskCard key={task.id} task={task} onClick={() => onSelect(task)} />
          ))}
        </div>
      )}
    </div>
  );
}

function TaskCard({ task, onClick }: { task: Task; onClick: () => void }) {
  const priorityCfg = PRIORITY_CONFIG[task.priority];
  const statusCfg = STATUS_CONFIG[task.status];
  const typeCfg = TYPE_CONFIG[task.type];

  return (
    <button onClick={onClick} className="w-full p-4 text-left hover:bg-slate-50 transition flex gap-3">
      {/* Priority indicator */}
      <div className={`w-1 rounded-full ${priorityCfg.color} flex-shrink-0`} />
      
      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-sm">{typeCfg.icon}</span>
          <span className="font-mono text-xs text-slate-400">{task.code}</span>
          <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${priorityCfg.color} text-white`}>
            {task.priority}
          </span>
        </div>
        
        <h4 className="font-medium text-slate-800 truncate">{task.title}</h4>
        
        <div className="flex items-center gap-3 mt-2 text-xs text-slate-500">
          {task.assetName && (
            <span className="flex items-center gap-1">
              <Wrench className="w-3 h-3" />
              {task.assetName}
            </span>
          )}
          {task.assigneeName && (
            <span className="flex items-center gap-1">
              <User className="w-3 h-3" />
              {task.assigneeName}
            </span>
          )}
        </div>
        
        {/* Kdo zadal a kdy */}
        <div className="flex items-center gap-3 mt-1.5 text-[10px] text-slate-400">
          <span>Zadal: {task.createdByName}</span>
          <span>•</span>
          <span>{task.createdAt.toLocaleDateString('cs-CZ')}</span>
        </div>
      </div>

      {/* Assignee */}
      {task.assigneeColor && (
        <UserBadge name={task.assigneeName || ''} color={task.assigneeColor} size="sm" />
      )}

      <ChevronRight className="w-5 h-5 text-slate-300 flex-shrink-0" />
    </button>
  );
}

function TaskDetailModal({ task, onClose, onStart, onComplete, canAssign }: {
  task: Task; onClose: () => void; onStart: () => void; onComplete: () => void; canAssign: boolean;
}) {
  const priorityCfg = PRIORITY_CONFIG[task.priority];
  const statusCfg = STATUS_CONFIG[task.status];
  const typeCfg = TYPE_CONFIG[task.type];
  const StatusIcon = statusCfg.icon;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end md:items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-t-3xl md:rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="sticky top-0 bg-white border-b p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className={`px-2 py-1 rounded text-xs font-bold ${priorityCfg.color} text-white`}>{task.priority}</span>
            <span className="font-mono text-sm text-slate-500">{task.code}</span>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Title & Type */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xl">{typeCfg.icon}</span>
              <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${statusCfg.color} text-white flex items-center gap-1`}>
                <StatusIcon className="w-3 h-3" />
                {statusCfg.label}
              </span>
            </div>
            <h2 className="text-xl font-bold text-slate-800">{task.title}</h2>
          </div>

          {/* Description */}
          {task.description && (
            <p className="text-slate-600 bg-slate-50 p-3 rounded-xl">{task.description}</p>
          )}

          {/* Meta */}
          <div className="grid grid-cols-2 gap-3">
            {task.assetName && (
              <div className="bg-slate-50 p-3 rounded-xl">
                <div className="text-xs text-slate-500 mb-1">Stroj</div>
                <div className="font-medium flex items-center gap-2">
                  <Wrench className="w-4 h-4 text-slate-400" />
                  {task.assetName}
                </div>
              </div>
            )}
            <div className="bg-slate-50 p-3 rounded-xl">
              <div className="text-xs text-slate-500 mb-1">Priorita</div>
              <div className="font-medium flex items-center gap-2">
                <Flag className="w-4 h-4" style={{ color: priorityCfg.color.replace('bg-', '') }} />
                {priorityCfg.description}
              </div>
            </div>
            {task.plannedDate && (
              <div className="bg-slate-50 p-3 rounded-xl">
                <div className="text-xs text-slate-500 mb-1">Plánováno</div>
                <div className="font-medium flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-slate-400" />
                  {new Date(task.plannedDate).toLocaleDateString('cs-CZ')}
                </div>
              </div>
            )}
            {task.estimatedMinutes && (
              <div className="bg-slate-50 p-3 rounded-xl">
                <div className="text-xs text-slate-500 mb-1">Odhad</div>
                <div className="font-medium flex items-center gap-2">
                  <Clock className="w-4 h-4 text-slate-400" />
                  {task.estimatedMinutes} min
                </div>
              </div>
            )}
          </div>

          {/* Assignee */}
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-xl">
            <div className="text-sm text-slate-500">Přiřazeno:</div>
            {task.assigneeName ? (
              <div className="flex items-center gap-2">
                <UserBadge name={task.assigneeName} color={task.assigneeColor || '#64748b'} size="sm" />
                <span className="font-medium">{task.assigneeName}</span>
              </div>
            ) : (
              <span className="text-slate-400">Nepřiřazeno</span>
            )}
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-2">
            {task.status === 'backlog' && (
              <button onClick={onStart} className="flex-1 py-3 bg-amber-500 text-white rounded-xl font-bold hover:bg-amber-600 flex items-center justify-center gap-2">
                <Play className="w-5 h-5" /> Zahájit
              </button>
            )}
            {task.status === 'planned' && (
              <button onClick={onStart} className="flex-1 py-3 bg-amber-500 text-white rounded-xl font-bold hover:bg-amber-600 flex items-center justify-center gap-2">
                <Play className="w-5 h-5" /> Zahájit
              </button>
            )}
            {task.status === 'in_progress' && (
              <button onClick={onComplete} className="flex-1 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 flex items-center justify-center gap-2">
                <CheckCircle2 className="w-5 h-5" /> Dokončit
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function NewTaskModal({ onClose, onCreate, user, roleMeta, assetId }: {
  onClose: () => void;
  onCreate: (task: Task) => void;
  user: any;
  roleMeta: any;
  assetId?: string;
}) {
  const [form, setForm] = useState({
    title: '',
    description: '',
    type: 'corrective' as TaskType,
    priority: 'P2' as TaskPriority,
    assetName: assetId ? 'Načítám...' : '',
  });

  const handleSubmit = () => {
    if (!form.title.trim()) return;

    const newTask: Task = {
      id: `t${Date.now()}`,
      code: `WO-2026-${String(Math.floor(Math.random() * 1000)).padStart(3, '0')}`,
      title: form.title,
      description: form.description || undefined,
      type: form.type,
      status: 'backlog',
      priority: form.priority,
      assetId: assetId,
      assetName: form.assetName || undefined,
      createdById: user?.id || 'unknown',
      createdByName: user?.displayName || 'Neznámý',
      createdAt: new Date(),
    };

    onCreate(newTask);
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end md:items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-t-3xl md:rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="sticky top-0 bg-white border-b p-4 flex items-center justify-between">
          <h2 className="text-lg font-bold">Nový úkol</h2>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Type */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Typ</label>
            <div className="grid grid-cols-2 gap-2">
              {Object.entries(TYPE_CONFIG).map(([key, cfg]) => (
                <button
                  key={key}
                  onClick={() => setForm(p => ({ ...p, type: key as TaskType }))}
                  className={`p-3 rounded-xl border-2 text-sm font-medium transition ${
                    form.type === key ? 'border-blue-500 bg-blue-50' : 'border-slate-200'
                  }`}
                >
                  <span className="mr-2">{cfg.icon}</span>
                  {cfg.label}
                </button>
              ))}
            </div>
          </div>

          {/* Priority */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Priorita</label>
            <div className="grid grid-cols-4 gap-2">
              {Object.entries(PRIORITY_CONFIG).map(([key, cfg]) => (
                <button
                  key={key}
                  onClick={() => setForm(p => ({ ...p, priority: key as TaskPriority }))}
                  className={`p-2 rounded-xl border-2 text-xs font-bold transition ${
                    form.priority === key ? 'border-slate-800 bg-slate-100' : 'border-slate-200'
                  }`}
                >
                  <span className={`inline-block w-2 h-2 rounded-full ${cfg.color} mr-1`} />
                  {cfg.label}
                </button>
              ))}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Název</label>
            <input
              type="text"
              value={form.title}
              onChange={(e) => setForm(p => ({ ...p, title: e.target.value }))}
              placeholder="Co je potřeba udělat?"
              className="w-full p-3 border rounded-xl focus:border-blue-500 outline-none"
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Popis</label>
            <textarea
              value={form.description}
              onChange={(e) => setForm(p => ({ ...p, description: e.target.value }))}
              placeholder="Podrobnosti..."
              className="w-full p-3 border rounded-xl focus:border-blue-500 outline-none resize-none"
              rows={3}
            />
          </div>

          {/* Asset */}
          {assetId && (
            <div className="bg-blue-50 border border-blue-200 p-3 rounded-xl">
              <div className="text-xs text-blue-600 mb-1">Napojeno na stroj</div>
              <div className="font-medium text-blue-800 flex items-center gap-2">
                <Wrench className="w-4 h-4" />
                {form.assetName}
              </div>
            </div>
          )}

          {/* Submit */}
          <button
            onClick={handleSubmit}
            disabled={!form.title.trim()}
            className="w-full py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2"
          >
            <Send className="w-5 h-5" />
            Vytvořit úkol
          </button>
        </div>
      </div>
    </div>
  );
}
