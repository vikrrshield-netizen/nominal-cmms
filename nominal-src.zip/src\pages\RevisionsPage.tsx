// src/pages/RevisionsPage.tsx
// NOMINAL CMMS — Správa revizí s dokumenty a připomínkami

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthContext } from '../context/AuthContext';
import { 
  Building, AlertCircle, Clock, CheckCircle2, FileWarning, ChevronRight, Plus,
  X, Calendar, FileText, MessageSquare, Upload, Download, Edit2, Save, 
  User, Paperclip, History, Shield
} from 'lucide-react';
import { Breadcrumb } from '../components/ui';

// ═══════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════

type RevisionType = 'FIRE' | 'ELEC' | 'PRESSURE' | 'LIFT' | 'GAS' | 'CALIBRATION';
type RevisionStatus = 'OK' | 'WARNING' | 'CRITICAL';

interface RevisionDocument {
  id: string;
  name: string;
  type: 'pdf' | 'doc' | 'img';
  uploadedAt: string;
  uploadedBy: string;
  url?: string;
}

interface RevisionComment {
  id: string;
  text: string;
  author: string;
  authorColor: string;
  createdAt: string;
}

interface RevisionHistory {
  id: string;
  date: string;
  provider: string;
  result: 'pass' | 'fail' | 'conditional';
  notes?: string;
  documentId?: string;
}

interface Revision {
  id: string;
  title: string;
  building: string;
  buildingId: string;
  type: RevisionType;
  dueDate: string;
  status: RevisionStatus;
  lastRevision?: string;
  provider?: string;
  notes?: string;
  interval: number; // měsíce
  documents: RevisionDocument[];
  comments: RevisionComment[];
  history: RevisionHistory[];
  assignedTo?: string;
}

// ═══════════════════════════════════════════════════════════════════
// CONFIG
// ═══════════════════════════════════════════════════════════════════

const BUILDINGS = [
  { id: 'A', name: 'Administrativa' },
  { id: 'B', name: 'Spojovací krček' },
  { id: 'C', name: 'Zázemí & Vedení' },
  { id: 'D', name: 'Výrobní hala' },
  { id: 'E', name: 'Dílna & Sklad ND' },
  { id: 'L', name: 'Loupárna' },
];

const TYPE_CONFIG: Record<RevisionType, { label: string; icon: string; color: string }> = {
  FIRE: { label: 'Požární', icon: '🔥', color: 'bg-red-100 text-red-600' },
  ELEC: { label: 'Elektro', icon: '⚡', color: 'bg-yellow-100 text-yellow-600' },
  PRESSURE: { label: 'Tlakové nádoby', icon: '🔵', color: 'bg-blue-100 text-blue-600' },
  LIFT: { label: 'Výtahy', icon: '🛗', color: 'bg-purple-100 text-purple-600' },
  GAS: { label: 'Plyn', icon: '🔶', color: 'bg-orange-100 text-orange-600' },
  CALIBRATION: { label: 'Kalibrace', icon: '⚖️', color: 'bg-teal-100 text-teal-600' },
};

// ═══════════════════════════════════════════════════════════════════
// MOCK DATA
// ═══════════════════════════════════════════════════════════════════

const MOCK_REVISIONS: Revision[] = [
  { 
    id: 'r1', 
    title: 'Revize hasicích přístrojů', 
    building: 'Výrobní hala', 
    buildingId: 'D',
    type: 'FIRE', 
    dueDate: '2026-03-01', 
    status: 'CRITICAL', 
    provider: 'POŽÁRNÍ BEZPEČNOST s.r.o.',
    interval: 12,
    lastRevision: '2025-03-01',
    assignedTo: 'Pavla',
    documents: [
      { id: 'd1', name: 'Revizní zpráva 2025.pdf', type: 'pdf', uploadedAt: '2025-03-05', uploadedBy: 'Vilém' },
      { id: 'd2', name: 'Seznam hasicích přístrojů.xlsx', type: 'doc', uploadedAt: '2024-01-15', uploadedBy: 'Pavla' },
    ],
    comments: [
      { id: 'c1', text: 'Nutné objednat revizního technika min. 2 týdny předem!', author: 'Vilém', authorColor: '#16a34a', createdAt: '2026-02-10' },
    ],
    history: [
      { id: 'h1', date: '2025-03-01', provider: 'POŽÁRNÍ BEZPEČNOST s.r.o.', result: 'pass', notes: 'Vše v pořádku' },
      { id: 'h2', date: '2024-03-01', provider: 'POŽÁRNÍ BEZPEČNOST s.r.o.', result: 'conditional', notes: 'Vyměnit 2 ks HP v balírně' },
    ],
  },
  { 
    id: 'r2', 
    title: 'Elektro revize rozvaděčů', 
    building: 'Výrobní hala', 
    buildingId: 'D',
    type: 'ELEC', 
    dueDate: '2026-04-15', 
    status: 'WARNING',
    interval: 36,
    lastRevision: '2023-04-15',
    documents: [
      { id: 'd3', name: 'Elektro revize 2023.pdf', type: 'pdf', uploadedAt: '2023-04-20', uploadedBy: 'Vilém' },
    ],
    comments: [],
    history: [
      { id: 'h3', date: '2023-04-15', provider: 'ELMONT s.r.o.', result: 'pass' },
    ],
  },
  { 
    id: 'r3', 
    title: 'Tlakové nádoby (Kompresorovna)', 
    building: 'Výrobní hala', 
    buildingId: 'D',
    type: 'PRESSURE', 
    dueDate: '2026-11-20', 
    status: 'OK',
    interval: 48,
    documents: [],
    comments: [],
    history: [],
  },
  { 
    id: 'r4', 
    title: 'Revize výtahu', 
    building: 'Výrobní hala', 
    buildingId: 'D',
    type: 'LIFT', 
    dueDate: '2026-06-01', 
    status: 'OK',
    interval: 12,
    documents: [],
    comments: [],
    history: [],
  },
  { 
    id: 'r5', 
    title: 'Kalibrace vah', 
    building: 'Výrobní hala', 
    buildingId: 'D',
    type: 'CALIBRATION', 
    dueDate: '2026-02-28', 
    status: 'CRITICAL', 
    notes: 'Nutné pro IFS audit!',
    interval: 12,
    assignedTo: 'Pavla',
    documents: [],
    comments: [
      { id: 'c2', text: 'Kontaktovat METTLER TOLEDO', author: 'Pavla', authorColor: '#d97706', createdAt: '2026-02-08' },
    ],
    history: [],
  },
  { 
    id: 'r6', 
    title: 'Revize elektrických zařízení', 
    building: 'Loupárna', 
    buildingId: 'L',
    type: 'ELEC', 
    dueDate: '2026-05-15', 
    status: 'OK',
    interval: 36,
    documents: [],
    comments: [],
    history: [],
  },
];

// ═══════════════════════════════════════════════════════════════════
// COMPONENT
// ═══════════════════════════════════════════════════════════════════

export default function RevisionsPage() {
  const navigate = useNavigate();
  const { hasPermission, user } = useAuthContext();
  
  const [revisions, setRevisions] = useState<Revision[]>(MOCK_REVISIONS);
  const [filterStatus, setFilterStatus] = useState<RevisionStatus | 'ALL'>('ALL');
  const [filterBuilding, setFilterBuilding] = useState<string | 'ALL'>('ALL');
  const [selectedRevision, setSelectedRevision] = useState<Revision | null>(null);
  const [showNewModal, setShowNewModal] = useState(false);
  
  // Správa revizí = SUPERADMIN nebo VEDENI
  const canManageRevisions = hasPermission('user.manage') || hasPermission('wo.approve');

  const filteredRevisions = revisions.filter(rev => {
    if (filterStatus !== 'ALL' && rev.status !== filterStatus) return false;
    if (filterBuilding !== 'ALL' && rev.buildingId !== filterBuilding) return false;
    return true;
  });

  const stats = {
    critical: revisions.filter(r => r.status === 'CRITICAL').length,
    warning: revisions.filter(r => r.status === 'WARNING').length,
    ok: revisions.filter(r => r.status === 'OK').length,
  };

  const formatDate = (dateStr: string) => new Date(dateStr).toLocaleDateString('cs-CZ', { day: 'numeric', month: 'long', year: 'numeric' });
  const getDaysUntil = (dateStr: string) => Math.ceil((new Date(dateStr).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Header */}
      <div className="bg-white border-b px-4 py-4">
        <Breadcrumb items={[{ label: 'Dashboard', onClick: () => navigate('/') }, { label: 'Revize a Termíny' }]} />
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-slate-800">Správa Revizí</h1>
            {canManageRevisions && (
              <p className="text-xs text-emerald-600 flex items-center gap-1 mt-1">
                <Shield className="w-3 h-3" />
                Máte oprávnění ke správě
              </p>
            )}
          </div>
          {canManageRevisions && (
            <button 
              onClick={() => setShowNewModal(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium flex items-center gap-2 hover:bg-blue-700"
            >
              <Plus className="w-5 h-5" />
              <span className="hidden sm:inline">Nová revize</span>
            </button>
          )}
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* Filtr budov */}
        <div>
          <h2 className="text-sm font-bold text-slate-500 uppercase mb-3">Filtr dle budovy</h2>
          <div className="flex gap-2 overflow-x-auto pb-2">
            <button
              onClick={() => setFilterBuilding('ALL')}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition ${
                filterBuilding === 'ALL' ? 'bg-slate-800 text-white' : 'bg-white border text-slate-600'
              }`}
            >
              Vše
            </button>
            {BUILDINGS.map(b => (
              <button
                key={b.id}
                onClick={() => setFilterBuilding(b.id)}
                className={`px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition flex items-center gap-1.5 ${
                  filterBuilding === b.id ? 'bg-slate-800 text-white' : 'bg-white border text-slate-600'
                }`}
              >
                <span className="font-bold">{b.id}</span>
                <span className="hidden sm:inline">{b.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Semafor */}
        <div className="grid grid-cols-3 gap-3">
          <button 
            onClick={() => setFilterStatus(filterStatus === 'CRITICAL' ? 'ALL' : 'CRITICAL')}
            className={`p-4 rounded-xl border-2 transition ${filterStatus === 'CRITICAL' ? 'border-red-500 bg-red-50' : 'border-slate-200 bg-white'}`}
          >
            <div className="flex items-center justify-center gap-2 mb-1">
              <FileWarning className={`w-5 h-5 ${stats.critical > 0 ? 'text-red-500 animate-pulse' : 'text-slate-400'}`} />
              <span className="text-2xl font-bold text-red-600">{stats.critical}</span>
            </div>
            <span className="text-xs text-slate-500">Kritické</span>
          </button>
          <button 
            onClick={() => setFilterStatus(filterStatus === 'WARNING' ? 'ALL' : 'WARNING')}
            className={`p-4 rounded-xl border-2 transition ${filterStatus === 'WARNING' ? 'border-amber-500 bg-amber-50' : 'border-slate-200 bg-white'}`}
          >
            <div className="flex items-center justify-center gap-2 mb-1">
              <Clock className="w-5 h-5 text-amber-500" />
              <span className="text-2xl font-bold text-amber-600">{stats.warning}</span>
            </div>
            <span className="text-xs text-slate-500">Blíží se</span>
          </button>
          <button 
            onClick={() => setFilterStatus(filterStatus === 'OK' ? 'ALL' : 'OK')}
            className={`p-4 rounded-xl border-2 transition ${filterStatus === 'OK' ? 'border-emerald-500 bg-emerald-50' : 'border-slate-200 bg-white'}`}
          >
            <div className="flex items-center justify-center gap-2 mb-1">
              <CheckCircle2 className="w-5 h-5 text-emerald-500" />
              <span className="text-2xl font-bold text-emerald-600">{stats.ok}</span>
            </div>
            <span className="text-xs text-slate-500">V pořádku</span>
          </button>
        </div>

        {/* Seznam revizí */}
        <div className="bg-white rounded-xl shadow-sm border overflow-hidden">
          <div className="p-4 border-b bg-slate-50 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-rose-500" />
              <h3 className="font-bold text-slate-800">Semafor Termínů</h3>
            </div>
            <span className="text-sm text-slate-500">{filteredRevisions.length} položek</span>
          </div>
          
          <div className="divide-y">
            {filteredRevisions.map((rev) => {
              const typeConfig = TYPE_CONFIG[rev.type];
              const daysUntil = getDaysUntil(rev.dueDate);
              const hasDocuments = rev.documents.length > 0;
              const hasComments = rev.comments.length > 0;

              return (
                <button
                  key={rev.id}
                  onClick={() => setSelectedRevision(rev)}
                  className="w-full p-4 hover:bg-slate-50 flex items-center gap-4 text-left transition"
                >
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl ${
                    rev.status === 'CRITICAL' ? 'bg-red-100 animate-pulse' :
                    rev.status === 'WARNING' ? 'bg-amber-100' : 'bg-emerald-100'
                  }`}>
                    {typeConfig.icon}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${typeConfig.color}`}>
                        {typeConfig.label}
                      </span>
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-600">
                        {rev.buildingId}
                      </span>
                    </div>
                    <h4 className="font-bold text-slate-800 truncate">{rev.title}</h4>
                    <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
                      <span>{rev.building}</span>
                      {hasDocuments && (
                        <span className="flex items-center gap-1 text-blue-500">
                          <Paperclip className="w-3 h-3" />
                          {rev.documents.length}
                        </span>
                      )}
                      {hasComments && (
                        <span className="flex items-center gap-1 text-purple-500">
                          <MessageSquare className="w-3 h-3" />
                          {rev.comments.length}
                        </span>
                      )}
                    </div>
                    {rev.notes && <p className="text-xs text-amber-600 mt-1">⚠️ {rev.notes}</p>}
                  </div>
                  
                  <div className="text-right flex-shrink-0">
                    <div className="font-mono text-sm text-slate-700">{formatDate(rev.dueDate)}</div>
                    <div className={`text-xs font-medium ${
                      daysUntil < 0 ? 'text-red-600' : daysUntil < 30 ? 'text-amber-600' : 'text-slate-400'
                    }`}>
                      {daysUntil < 0 ? `${Math.abs(daysUntil)} dní po!` : daysUntil === 0 ? 'Dnes!' : `za ${daysUntil} dní`}
                    </div>
                    {rev.assignedTo && (
                      <div className="text-xs text-slate-400 mt-1">→ {rev.assignedTo}</div>
                    )}
                  </div>
                  
                  <ChevronRight className="w-5 h-5 text-slate-300 flex-shrink-0" />
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedRevision && (
        <RevisionDetailModal
          revision={selectedRevision}
          onClose={() => setSelectedRevision(null)}
          canManage={canManageRevisions}
          currentUser={user?.displayName || 'Uživatel'}
          onUpdate={(updated) => {
            setRevisions(prev => prev.map(r => r.id === updated.id ? updated : r));
            setSelectedRevision(updated);
          }}
        />
      )}

      {/* New Revision Modal */}
      {showNewModal && canManageRevisions && (
        <NewRevisionModal
          onClose={() => setShowNewModal(false)}
          onSave={(newRev) => {
            setRevisions(prev => [...prev, newRev]);
            setShowNewModal(false);
          }}
        />
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// DETAIL MODAL
// ═══════════════════════════════════════════════════════════════════

function RevisionDetailModal({ revision, onClose, canManage, currentUser, onUpdate }: {
  revision: Revision;
  onClose: () => void;
  canManage: boolean;
  currentUser: string;
  onUpdate: (rev: Revision) => void;
}) {
  const [activeTab, setActiveTab] = useState<'info' | 'documents' | 'comments' | 'history'>('info');
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({
    dueDate: revision.dueDate,
    provider: revision.provider || '',
    notes: revision.notes || '',
    assignedTo: revision.assignedTo || '',
  });
  const [newComment, setNewComment] = useState('');

  const typeConfig = TYPE_CONFIG[revision.type];

  const handleSave = () => {
    onUpdate({
      ...revision,
      dueDate: editData.dueDate,
      provider: editData.provider,
      notes: editData.notes,
      assignedTo: editData.assignedTo,
    });
    setIsEditing(false);
  };

  const handleAddComment = () => {
    if (!newComment.trim()) return;
    const comment: RevisionComment = {
      id: `c${Date.now()}`,
      text: newComment.trim(),
      author: currentUser,
      authorColor: '#16a34a',
      createdAt: new Date().toISOString().split('T')[0],
    };
    onUpdate({
      ...revision,
      comments: [...revision.comments, comment],
    });
    setNewComment('');
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end md:items-center justify-center" onClick={onClose}>
      <div className="bg-white rounded-t-3xl md:rounded-3xl w-full max-w-lg max-h-[90vh] overflow-hidden" onClick={e => e.stopPropagation()}>
        {/* Header */}
        <div className={`p-4 ${
          revision.status === 'CRITICAL' ? 'bg-red-500' :
          revision.status === 'WARNING' ? 'bg-amber-500' : 'bg-emerald-500'
        } text-white`}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-3xl">{typeConfig.icon}</span>
            <button onClick={onClose} className="p-2 rounded-lg bg-white/20 hover:bg-white/30">
              <X className="w-5 h-5" />
            </button>
          </div>
          <h2 className="text-xl font-bold">{revision.title}</h2>
          <p className="text-white/80 text-sm">{revision.building} (Budova {revision.buildingId})</p>
        </div>

        {/* Tabs */}
        <div className="flex border-b">
          {[
            { id: 'info', label: 'Info', icon: FileText },
            { id: 'documents', label: 'Dokumenty', icon: Paperclip, count: revision.documents.length },
            { id: 'comments', label: 'Připomínky', icon: MessageSquare, count: revision.comments.length },
            { id: 'history', label: 'Historie', icon: History, count: revision.history.length },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex-1 p-3 text-sm font-medium flex items-center justify-center gap-1 ${
                activeTab === tab.id ? 'border-b-2 border-blue-500 text-blue-600' : 'text-slate-500'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              <span className="hidden sm:inline">{tab.label}</span>
              {tab.count !== undefined && tab.count > 0 && (
                <span className="ml-1 px-1.5 py-0.5 bg-slate-200 rounded-full text-[10px]">{tab.count}</span>
              )}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="p-4 overflow-y-auto max-h-[50vh]">
          {activeTab === 'info' && (
            <div className="space-y-4">
              {canManage && !isEditing && (
                <button
                  onClick={() => setIsEditing(true)}
                  className="w-full flex items-center justify-center gap-2 p-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100"
                >
                  <Edit2 className="w-4 h-4" />
                  Upravit údaje
                </button>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs text-slate-500">Termín revize</label>
                  {isEditing ? (
                    <input
                      type="date"
                      value={editData.dueDate}
                      onChange={e => setEditData(prev => ({ ...prev, dueDate: e.target.value }))}
                      className="w-full p-2 border rounded-lg mt-1"
                    />
                  ) : (
                    <p className="font-medium">{new Date(revision.dueDate).toLocaleDateString('cs-CZ')}</p>
                  )}
                </div>
                <div>
                  <label className="text-xs text-slate-500">Interval</label>
                  <p className="font-medium">{revision.interval} měsíců</p>
                </div>
                <div>
                  <label className="text-xs text-slate-500">Typ revize</label>
                  <p className="font-medium">{typeConfig.label}</p>
                </div>
                <div>
                  <label className="text-xs text-slate-500">Odpovědná osoba</label>
                  {isEditing ? (
                    <input
                      type="text"
                      value={editData.assignedTo}
                      onChange={e => setEditData(prev => ({ ...prev, assignedTo: e.target.value }))}
                      className="w-full p-2 border rounded-lg mt-1"
                      placeholder="Jméno"
                    />
                  ) : (
                    <p className="font-medium">{revision.assignedTo || '—'}</p>
                  )}
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-500">Dodavatel</label>
                {isEditing ? (
                  <input
                    type="text"
                    value={editData.provider}
                    onChange={e => setEditData(prev => ({ ...prev, provider: e.target.value }))}
                    className="w-full p-2 border rounded-lg mt-1"
                    placeholder="Název firmy"
                  />
                ) : (
                  <p className="font-medium">{revision.provider || '—'}</p>
                )}
              </div>

              <div>
                <label className="text-xs text-slate-500">Poznámky</label>
                {isEditing ? (
                  <textarea
                    value={editData.notes}
                    onChange={e => setEditData(prev => ({ ...prev, notes: e.target.value }))}
                    className="w-full p-2 border rounded-lg mt-1 h-24 resize-none"
                    placeholder="Důležité poznámky..."
                  />
                ) : (
                  <p className={`font-medium ${revision.notes ? 'text-amber-600' : 'text-slate-400'}`}>
                    {revision.notes || '—'}
                  </p>
                )}
              </div>

              {isEditing && (
                <div className="flex gap-2">
                  <button
                    onClick={() => setIsEditing(false)}
                    className="flex-1 p-2 border rounded-lg text-slate-600"
                  >
                    Zrušit
                  </button>
                  <button
                    onClick={handleSave}
                    className="flex-1 p-2 bg-blue-600 text-white rounded-lg flex items-center justify-center gap-2"
                  >
                    <Save className="w-4 h-4" />
                    Uložit
                  </button>
                </div>
              )}
            </div>
          )}

          {activeTab === 'documents' && (
            <div className="space-y-3">
              {canManage && (
                <button className="w-full flex items-center justify-center gap-2 p-3 border-2 border-dashed border-slate-300 rounded-xl text-slate-500 hover:border-blue-400 hover:text-blue-500">
                  <Upload className="w-5 h-5" />
                  Nahrát dokument
                </button>
              )}

              {revision.documents.length === 0 ? (
                <p className="text-center text-slate-500 py-8">Žádné dokumenty</p>
              ) : (
                revision.documents.map(doc => (
                  <div key={doc.id} className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <FileText className="w-5 h-5 text-blue-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{doc.name}</p>
                      <p className="text-xs text-slate-500">
                        {doc.uploadedBy} • {new Date(doc.uploadedAt).toLocaleDateString('cs-CZ')}
                      </p>
                    </div>
                    <button className="p-2 rounded-lg hover:bg-slate-200">
                      <Download className="w-4 h-4 text-slate-600" />
                    </button>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'comments' && (
            <div className="space-y-3">
              {/* Add comment */}
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newComment}
                  onChange={e => setNewComment(e.target.value)}
                  placeholder="Přidat připomínku..."
                  className="flex-1 p-2 border rounded-lg text-sm"
                  onKeyDown={e => e.key === 'Enter' && handleAddComment()}
                />
                <button
                  onClick={handleAddComment}
                  disabled={!newComment.trim()}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg disabled:opacity-50"
                >
                  <MessageSquare className="w-4 h-4" />
                </button>
              </div>

              {revision.comments.length === 0 ? (
                <p className="text-center text-slate-500 py-8">Žádné připomínky</p>
              ) : (
                revision.comments.map(comment => (
                  <div key={comment.id} className="p-3 bg-slate-50 rounded-xl">
                    <div className="flex items-center gap-2 mb-2">
                      <div 
                        className="w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold"
                        style={{ backgroundColor: comment.authorColor }}
                      >
                        {comment.author.charAt(0)}
                      </div>
                      <span className="font-medium text-sm">{comment.author}</span>
                      <span className="text-xs text-slate-400">{comment.createdAt}</span>
                    </div>
                    <p className="text-sm text-slate-700">{comment.text}</p>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-3">
              {revision.history.length === 0 ? (
                <p className="text-center text-slate-500 py-8">Žádná historie revizí</p>
              ) : (
                revision.history.map(hist => (
                  <div key={hist.id} className="p-3 border rounded-xl">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium">{new Date(hist.date).toLocaleDateString('cs-CZ')}</span>
                      <span className={`px-2 py-0.5 rounded text-xs font-bold ${
                        hist.result === 'pass' ? 'bg-emerald-100 text-emerald-600' :
                        hist.result === 'fail' ? 'bg-red-100 text-red-600' : 'bg-amber-100 text-amber-600'
                      }`}>
                        {hist.result === 'pass' ? 'Prošlo' : hist.result === 'fail' ? 'Neprošlo' : 'S výhradou'}
                      </span>
                    </div>
                    <p className="text-sm text-slate-600">{hist.provider}</p>
                    {hist.notes && <p className="text-xs text-slate-500 mt-1">{hist.notes}</p>}
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// NEW REVISION MODAL
// ═══════════════════════════════════════════════════════════════════

function NewRevisionModal({ onClose, onSave }: {
  onClose: () => void;
  onSave: (revision: Revision) => void;
}) {
  const [formData, setFormData] = useState({
    title: '',
    buildingId: 'D',
    type: 'FIRE' as RevisionType,
    dueDate: '',
    interval: 12,
    provider: '',
    notes: '',
    assignedTo: '',
  });

  const handleSubmit = () => {
    if (!formData.title || !formData.dueDate) return;
    
    const building = BUILDINGS.find(b => b.id === formData.buildingId);
    const newRevision: Revision = {
      id: `r${Date.now()}`,
      title: formData.title,
      building: building?.name || '',
      buildingId: formData.buildingId,
      type: formData.type,
      dueDate: formData.dueDate,
      status: 'OK',
      interval: formData.interval,
      provider: formData.provider || undefined,
      notes: formData.notes || undefined,
      assignedTo: formData.assignedTo || undefined,
      documents: [],
      comments: [],
      history: [],
    };
    onSave(newRevision);
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end md:items-center justify-center" onClick={onClose}>
      <div className="bg-white rounded-t-3xl md:rounded-3xl w-full max-w-lg max-h-[90vh] overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="p-4 border-b flex items-center justify-between">
          <h2 className="text-xl font-bold">Nová revize</h2>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4 overflow-y-auto max-h-[70vh]">
          <div>
            <label className="text-sm font-medium text-slate-700">Název *</label>
            <input
              type="text"
              value={formData.title}
              onChange={e => setFormData(prev => ({ ...prev, title: e.target.value }))}
              className="w-full p-2 border rounded-lg mt-1"
              placeholder="např. Revize hasicích přístrojů"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-slate-700">Budova *</label>
              <select
                value={formData.buildingId}
                onChange={e => setFormData(prev => ({ ...prev, buildingId: e.target.value }))}
                className="w-full p-2 border rounded-lg mt-1"
              >
                {BUILDINGS.map(b => (
                  <option key={b.id} value={b.id}>{b.id} — {b.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-sm font-medium text-slate-700">Typ *</label>
              <select
                value={formData.type}
                onChange={e => setFormData(prev => ({ ...prev, type: e.target.value as RevisionType }))}
                className="w-full p-2 border rounded-lg mt-1"
              >
                {Object.entries(TYPE_CONFIG).map(([key, cfg]) => (
                  <option key={key} value={key}>{cfg.icon} {cfg.label}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium text-slate-700">Termín *</label>
              <input
                type="date"
                value={formData.dueDate}
                onChange={e => setFormData(prev => ({ ...prev, dueDate: e.target.value }))}
                className="w-full p-2 border rounded-lg mt-1"
              />
            </div>
            <div>
              <label className="text-sm font-medium text-slate-700">Interval (měsíce)</label>
              <input
                type="number"
                value={formData.interval}
                onChange={e => setFormData(prev => ({ ...prev, interval: parseInt(e.target.value) || 12 }))}
                className="w-full p-2 border rounded-lg mt-1"
                min={1}
              />
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-slate-700">Dodavatel</label>
            <input
              type="text"
              value={formData.provider}
              onChange={e => setFormData(prev => ({ ...prev, provider: e.target.value }))}
              className="w-full p-2 border rounded-lg mt-1"
              placeholder="Název revizní firmy"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-slate-700">Odpovědná osoba</label>
            <input
              type="text"
              value={formData.assignedTo}
              onChange={e => setFormData(prev => ({ ...prev, assignedTo: e.target.value }))}
              className="w-full p-2 border rounded-lg mt-1"
              placeholder="Jméno"
            />
          </div>

          <div>
            <label className="text-sm font-medium text-slate-700">Poznámky</label>
            <textarea
              value={formData.notes}
              onChange={e => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              className="w-full p-2 border rounded-lg mt-1 h-20 resize-none"
              placeholder="Důležité informace..."
            />
          </div>
        </div>

        <div className="p-4 border-t flex gap-2">
          <button onClick={onClose} className="flex-1 p-3 border rounded-xl font-medium">
            Zrušit
          </button>
          <button
            onClick={handleSubmit}
            disabled={!formData.title || !formData.dueDate}
            className="flex-1 p-3 bg-blue-600 text-white rounded-xl font-medium disabled:opacity-50 flex items-center justify-center gap-2"
          >
            <Save className="w-5 h-5" />
            Uložit
          </button>
        </div>
      </div>
    </div>
  );
}
