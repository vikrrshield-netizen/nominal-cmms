// src/pages/AssetCardPage.tsx
// NOMINAL CMMS — Kartotéka stroje FÁZE 3 (editace, přidávání, nahlášení poruchy)

import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { assetService, workLogService, type WorkLogEntry } from '../services/assetService';
import { useAuthContext } from '../context/AuthContext';
import type { Asset, AssetStatus, AssetCriticality } from '../types/asset';
import { ASSET_STATUS_CONFIG, ASSET_CATEGORY_CONFIG, CRITICALITY_CONFIG } from '../types/asset';
import { UserBadge, StatusDot, LoadingSpinner } from '../components/ui';
import { Timeline, type TimelineEntry } from '../components/ui/Timeline';
import { 
  ChevronLeft, MapPin, Clock, FileText, Package, 
  AlertTriangle, Camera, QrCode, Edit3, MoreVertical, X,
  Save, Plus, Send, CheckCircle2
} from 'lucide-react';

// ═══════════════════════════════════════════════════════════════════
// TYPES & CONFIG
// ═══════════════════════════════════════════════════════════════════

type TabId = 'info' | 'history' | 'parts' | 'docs';
type ModalType = 'none' | 'edit' | 'addLog' | 'reportIssue';

const TABS: { id: TabId; label: string; icon: typeof Clock }[] = [
  { id: 'info', label: 'Info', icon: FileText },
  { id: 'history', label: 'Historie', icon: Clock },
  { id: 'parts', label: 'Díly', icon: Package },
  { id: 'docs', label: 'Dokumenty', icon: FileText },
];

const LOG_TYPES = [
  { value: 'preventive', label: 'Preventivní', color: 'bg-emerald-500' },
  { value: 'corrective', label: 'Oprava', color: 'bg-blue-500' },
  { value: 'inspection', label: 'Kontrola', color: 'bg-amber-500' },
  { value: 'incident', label: 'Incident', color: 'bg-red-500' },
  { value: 'note', label: 'Poznámka', color: 'bg-slate-500' },
];

const PRIORITIES = [
  { value: 'low', label: 'Nízká', color: 'bg-gray-400' },
  { value: 'medium', label: 'Střední', color: 'bg-blue-500' },
  { value: 'high', label: 'Vysoká', color: 'bg-orange-500' },
  { value: 'critical', label: 'Kritická', color: 'bg-red-600' },
];

// ═══════════════════════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════════════════════

export default function AssetCardPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { hasPermission, isReadOnly, user, roleMeta } = useAuthContext();

  // Data
  const [asset, setAsset] = useState<Asset | null>(null);
  const [logs, setLogs] = useState<WorkLogEntry[]>([]);
  
  // UI
  const [activeTab, setActiveTab] = useState<TabId>('info');
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [showActions, setShowActions] = useState(false);
  const [activeModal, setActiveModal] = useState<ModalType>('none');
  const [showSuccess, setShowSuccess] = useState(false);
  
  // Forms
  const [mthInput, setMthInput] = useState('');
  const [editForm, setEditForm] = useState<Partial<Asset>>({});
  const [logForm, setLogForm] = useState({ type: 'preventive' as WorkLogEntry['type'], title: '', description: '', duration: '' });
  const [issueForm, setIssueForm] = useState({ title: '', description: '', priority: 'high' as string });

  // Permissions
  const canEdit = hasPermission('asset.update') && !isReadOnly;
  const canCreateWO = hasPermission('wo.create');

  // ─────────────────────────────────────────────────────────────────
  // DATA LOADING
  // ─────────────────────────────────────────────────────────────────

  useEffect(() => {
    if (id) { loadAsset(id); loadLogs(id); }
  }, [id]);

  const loadAsset = async (assetId: string) => {
    setIsLoading(true);
    try {
      const data = await assetService.getById(assetId);
      setAsset(data);
      setMthInput((data.mthCounter || 0).toString());
      setEditForm(data);
    } catch (e) { console.error('Chyba:', e); }
    finally { setIsLoading(false); }
  };

  const loadLogs = async (assetId: string) => {
    try { const data = await workLogService.getByAsset(assetId); setLogs(data); }
    catch (e) { console.error('Chyba:', e); }
  };

  // ─────────────────────────────────────────────────────────────────
  // ACTIONS
  // ─────────────────────────────────────────────────────────────────

  const showSuccessToast = () => { setShowSuccess(true); setTimeout(() => setShowSuccess(false), 2000); };

  const handleUpdateMth = async () => {
    if (!asset || !canEdit) return;
    setIsSaving(true);
    try {
      await assetService.updateMth(asset.id, Number(mthInput));
      setAsset(prev => prev ? { ...prev, mthCounter: Number(mthInput) } : null);
      showSuccessToast();
    } finally { setIsSaving(false); }
  };

  const handleSaveEdit = async () => {
    if (!asset || !canEdit) return;
    setIsSaving(true);
    try {
      await assetService.update(asset.id, editForm);
      setAsset(prev => prev ? { ...prev, ...editForm } : null);
      setActiveModal('none');
      showSuccessToast();
    } finally { setIsSaving(false); }
  };

  const handleAddLog = async () => {
    if (!asset || !canEdit || !logForm.title.trim()) return;
    setIsSaving(true);
    try {
      const newLog: Omit<WorkLogEntry, 'id'> = {
        assetId: asset.id,
        type: logForm.type,
        title: logForm.title,
        description: logForm.description || undefined,
        duration: logForm.duration ? Number(logForm.duration) : undefined,
        userId: user?.id || 'unknown',
        userName: user?.displayName || 'Neznámý',
        userColor: roleMeta?.badgeHex || '#64748b',
        createdAt: new Date(),
      };
      await workLogService.add(newLog);
      await loadLogs(asset.id);
      setLogForm({ type: 'preventive', title: '', description: '', duration: '' });
      setActiveModal('none');
      showSuccessToast();
    } finally { setIsSaving(false); }
  };

  const handleReportIssue = async () => {
    if (!asset || !issueForm.title.trim()) return;
    setIsSaving(true);
    try {
      // 1. Změnit stav stroje
      await assetService.updateStatus(asset.id, 'broken');
      
      // 2. Přidat incident log
      const incidentLog: Omit<WorkLogEntry, 'id'> = {
        assetId: asset.id,
        type: 'incident',
        title: `🚨 ${issueForm.title}`,
        description: issueForm.description || undefined,
        userId: user?.id || 'unknown',
        userName: user?.displayName || 'Neznámý',
        userColor: roleMeta?.badgeHex || '#64748b',
        createdAt: new Date(),
      };
      await workLogService.add(incidentLog);
      
      // 3. TODO: Vytvořit Work Order
      console.log('CREATE_WORK_ORDER:', { assetId: asset.id, ...issueForm });
      
      // Refresh
      setAsset(prev => prev ? { ...prev, status: 'broken' } : null);
      await loadLogs(asset.id);
      setIssueForm({ title: '', description: '', priority: 'high' });
      setActiveModal('none');
      showSuccessToast();
    } finally { setIsSaving(false); }
  };

  // ─────────────────────────────────────────────────────────────────
  // HELPERS
  // ─────────────────────────────────────────────────────────────────

  const getStatusCfg = (s: string) => ASSET_STATUS_CONFIG[s as AssetStatus] || { label: s, color: 'bg-gray-500', icon: '❓' };
  const getCategoryCfg = (c: string) => ASSET_CATEGORY_CONFIG[c as keyof typeof ASSET_CATEGORY_CONFIG] || { label: c, icon: '📋' };
  const getCriticalityCfg = (c: string) => CRITICALITY_CONFIG[c as AssetCriticality] || { label: c, color: 'bg-gray-400', icon: '⚪' };
  const formatDate = (d?: Date | string) => d ? new Date(d).toLocaleDateString('cs-CZ') : '-';

  const timelineEntries: TimelineEntry[] = logs.map(l => ({
    id: l.id || '', type: l.type, title: l.title, description: l.description,
    userId: l.userId, userName: l.userName, userColor: l.userColor, createdAt: l.createdAt, duration: l.duration,
  }));

  // ─────────────────────────────────────────────────────────────────
  // RENDER: LOADING / ERROR
  // ─────────────────────────────────────────────────────────────────

  if (isLoading) return <div className="min-h-screen bg-gray-50 flex items-center justify-center"><LoadingSpinner size="lg" text="Načítám..." /></div>;
  if (!asset) return <div className="min-h-screen bg-gray-50 flex items-center justify-center"><div className="text-center"><p className="text-4xl mb-4">❌</p><h2 className="text-xl font-bold mb-2">Stroj nenalezen</h2><button onClick={() => navigate(-1)} className="text-blue-600">← Zpět</button></div></div>;

  const statusCfg = getStatusCfg(asset.status);
  const categoryCfg = getCategoryCfg(asset.category);
  const criticalityCfg = getCriticalityCfg(asset.criticality);

  // ═══════════════════════════════════════════════════════════════════
  // RENDER
  // ═══════════════════════════════════════════════════════════════════

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      
      {/* Success Toast */}
      {showSuccess && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 animate-bounce">
          <div className="bg-emerald-500 text-white px-6 py-3 rounded-xl shadow-lg flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5" /><span className="font-medium">Uloženo!</span>
          </div>
        </div>
      )}

      {/* HEADER */}
      <div className="bg-slate-800 text-white p-4 pt-6 rounded-b-3xl shadow-lg relative">
        <div className="flex items-center justify-between mb-4">
          <button onClick={() => navigate(-1)} className="flex items-center gap-1 text-slate-400 hover:text-white">
            <ChevronLeft className="w-5 h-5" /><span className="text-sm">Zpět</span>
          </button>
          <div className="flex items-center gap-2">
            {canEdit && <button onClick={() => setActiveModal('edit')} className="p-2 rounded-lg bg-slate-700 hover:bg-slate-600"><Edit3 className="w-5 h-5" /></button>}
            <button onClick={() => setShowActions(!showActions)} className="p-2 rounded-lg bg-slate-700 hover:bg-slate-600"><MoreVertical className="w-5 h-5" /></button>
          </div>
        </div>

        <div className="flex gap-4">
          <div className="w-16 h-16 rounded-2xl bg-slate-700 flex items-center justify-center text-3xl">{categoryCfg.icon}</div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <h1 className="text-xl font-bold truncate">{asset.name}</h1>
              <StatusDot status={asset.status} pulse={asset.status === 'broken'} />
            </div>
            <p className="text-sm text-slate-400 mb-2">{asset.code} • {asset.manufacturer || 'N/A'}</p>
            <div className="flex flex-wrap gap-2">
              <span className={`px-2 py-0.5 rounded text-xs font-medium ${statusCfg.color} text-white`}>{statusCfg.icon} {statusCfg.label}</span>
              <span className={`px-2 py-0.5 rounded text-xs font-medium ${criticalityCfg.color} text-white`}>{criticalityCfg.icon} {criticalityCfg.label}</span>
              {asset.buildingId && <span className="px-2 py-0.5 rounded text-xs bg-slate-600 text-slate-300 flex items-center gap-1"><MapPin className="w-3 h-3" />{asset.buildingId}</span>}
            </div>
          </div>
        </div>

        {isReadOnly && <div className="mt-4 bg-purple-500/20 border border-purple-400/50 rounded-xl px-4 py-2 flex items-center gap-2"><span>👑</span><span className="text-sm text-purple-300">Read-only</span></div>}

        {/* Dropdown */}
        {showActions && (
          <div className="absolute right-4 top-16 bg-slate-700 rounded-xl shadow-xl border border-slate-600 overflow-hidden z-20">
            <button onClick={() => { setActiveModal('edit'); setShowActions(false); }} className="w-full px-4 py-3 text-left text-sm hover:bg-slate-600 flex items-center gap-2"><Edit3 className="w-4 h-4" /> Upravit</button>
            <button onClick={() => { setActiveModal('addLog'); setShowActions(false); }} className="w-full px-4 py-3 text-left text-sm hover:bg-slate-600 flex items-center gap-2"><Plus className="w-4 h-4" /> Přidat záznam</button>
            <button className="w-full px-4 py-3 text-left text-sm hover:bg-slate-600 flex items-center gap-2"><Camera className="w-4 h-4" /> Fotka</button>
            <button className="w-full px-4 py-3 text-left text-sm hover:bg-slate-600 flex items-center gap-2"><QrCode className="w-4 h-4" /> QR kód</button>
            <button onClick={() => { setActiveModal('reportIssue'); setShowActions(false); }} className="w-full px-4 py-3 text-left text-sm hover:bg-slate-600 flex items-center gap-2 text-red-400"><AlertTriangle className="w-4 h-4" /> Nahlásit poruchu</button>
          </div>
        )}
      </div>

      {/* TABS */}
      <div className="flex bg-white border-b sticky top-0 z-10 shadow-sm">
        {TABS.map((tab) => {
          const Icon = tab.icon;
          return (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`flex-1 py-3 text-xs font-medium uppercase border-b-2 transition flex items-center justify-center gap-1.5 ${activeTab === tab.id ? 'border-blue-600 text-blue-600 bg-blue-50/50' : 'border-transparent text-slate-400'}`}>
              <Icon className="w-4 h-4" /><span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* CONTENT */}
      <div className="p-4 space-y-4">

        {/* TAB: INFO */}
        {activeTab === 'info' && (
          <>
            {asset.mthCounter !== undefined && (
              <div className="bg-white p-4 rounded-xl shadow-sm border">
                <div className="flex items-center justify-between mb-2">
                  <label className="text-sm font-medium text-slate-700 flex items-center gap-2"><Clock className="w-4 h-4 text-slate-400" />Motohodiny</label>
                  {canEdit && <span className="text-xs text-blue-500">Editovatelné</span>}
                </div>
                <div className="flex gap-2">
                  <input type="number" value={mthInput} onChange={(e) => setMthInput(e.target.value)} disabled={!canEdit}
                    className="flex-1 bg-slate-100 p-3 rounded-xl font-mono text-xl font-bold disabled:opacity-60 border-2 border-transparent focus:border-blue-500 outline-none" />
                  {canEdit && <button onClick={handleUpdateMth} disabled={isSaving} className="bg-blue-600 text-white px-6 rounded-xl font-bold hover:bg-blue-700 disabled:opacity-50">{isSaving ? '...' : 'Uložit'}</button>}
                </div>
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <InfoCard icon="🏭" label="Výrobce" value={asset.manufacturer || '-'} />
              <InfoCard icon="📋" label="Model" value={asset.model || '-'} />
              <InfoCard icon="📅" label="Rok" value={asset.year?.toString() || '-'} />
              <InfoCard icon="🔢" label="S/N" value={asset.serialNumber || '-'} />
              <InfoCard icon="🔧" label="Poslední servis" value={formatDate(asset.lastService)} />
              <InfoCard icon="📆" label="Příští servis" value={formatDate(asset.nextService)} highlight />
            </div>
            {asset.notes && <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl"><h4 className="text-sm font-bold text-amber-700 mb-1">📝 Poznámky</h4><p className="text-sm text-amber-800">{asset.notes}</p></div>}
            {canCreateWO && <button onClick={() => setActiveModal('reportIssue')} className="w-full py-4 bg-red-600 text-white rounded-xl font-bold shadow-lg hover:bg-red-700 active:scale-[0.98] transition flex items-center justify-center gap-3"><AlertTriangle className="w-5 h-5" /><span>NAHLÁSIT PORUCHU</span></button>}
          </>
        )}

        {/* TAB: HISTORY */}
        {activeTab === 'history' && (
          <div className="bg-white p-4 rounded-xl shadow-sm border">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-sm font-bold text-slate-500 uppercase flex items-center gap-2"><Clock className="w-4 h-4" />Digitální stopa</h3>
              {canEdit && <button onClick={() => setActiveModal('addLog')} className="text-blue-600 text-sm font-medium flex items-center gap-1"><Plus className="w-4 h-4" /> Přidat</button>}
            </div>
            <Timeline entries={timelineEntries} canAdd={canEdit} onAddClick={() => setActiveModal('addLog')} />
          </div>
        )}

        {/* TAB: PARTS */}
        {activeTab === 'parts' && (
          <div className="space-y-3">
            <h3 className="text-sm font-bold text-slate-500 uppercase flex items-center gap-2"><Package className="w-4 h-4" />Náhradní díly</h3>
            <PartCard name="Ložisko SKF 6205" code="SKF-6205" stock={2} unit="ks" />
            <PartCard name="Olej Shell Omala" code="OIL-SHELL-46" stock={120} unit="L" />
            <PartCard name="Těsnění DN50" code="SEAL-DN50" stock={0} unit="ks" alert />
            {hasPermission('inv.manage') && <button className="w-full py-3 border-2 border-dashed border-slate-300 rounded-xl text-slate-400 font-medium hover:border-blue-400 transition flex items-center justify-center gap-2"><Plus className="w-4 h-4" /> Přiřadit díl</button>}
          </div>
        )}

        {/* TAB: DOCS */}
        {activeTab === 'docs' && (
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <DocCard name="Manuál.pdf" icon="📕" size="2.4 MB" />
              <DocCard name="Schéma" icon="⚡" size="850 KB" />
              <DocCard name="Certifikát CE" icon="📜" size="320 KB" />
              <DocCard name="Fotogalerie" icon="📷" count={12} />
            </div>
            {canEdit && <button className="w-full py-3 bg-slate-100 rounded-xl text-slate-500 font-medium hover:bg-slate-200 flex items-center justify-center gap-2"><Camera className="w-4 h-4" /> Nahrát</button>}
          </div>
        )}
      </div>

      {/* ═══ MODALS ═══ */}
      
      {/* Modal: Edit */}
      {activeModal === 'edit' && (
        <Modal title="Upravit stroj" onClose={() => setActiveModal('none')}>
          <div className="space-y-4">
            <FormField label="Název"><input type="text" value={editForm.name || ''} onChange={(e) => setEditForm(p => ({ ...p, name: e.target.value }))} className="w-full p-3 border rounded-xl focus:border-blue-500 outline-none" /></FormField>
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Výrobce"><input type="text" value={editForm.manufacturer || ''} onChange={(e) => setEditForm(p => ({ ...p, manufacturer: e.target.value }))} className="w-full p-3 border rounded-xl focus:border-blue-500 outline-none" /></FormField>
              <FormField label="Model"><input type="text" value={editForm.model || ''} onChange={(e) => setEditForm(p => ({ ...p, model: e.target.value }))} className="w-full p-3 border rounded-xl focus:border-blue-500 outline-none" /></FormField>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <FormField label="Rok"><input type="number" value={editForm.year || ''} onChange={(e) => setEditForm(p => ({ ...p, year: Number(e.target.value) }))} className="w-full p-3 border rounded-xl focus:border-blue-500 outline-none" /></FormField>
              <FormField label="S/N"><input type="text" value={editForm.serialNumber || ''} onChange={(e) => setEditForm(p => ({ ...p, serialNumber: e.target.value }))} className="w-full p-3 border rounded-xl focus:border-blue-500 outline-none" /></FormField>
            </div>
            <FormField label="Stav">
              <select value={editForm.status || 'operational'} onChange={(e) => setEditForm(p => ({ ...p, status: e.target.value as AssetStatus }))} className="w-full p-3 border rounded-xl bg-white">
                {Object.entries(ASSET_STATUS_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.icon} {v.label}</option>)}
              </select>
            </FormField>
            <FormField label="Kritičnost">
              <select value={editForm.criticality || 'medium'} onChange={(e) => setEditForm(p => ({ ...p, criticality: e.target.value as AssetCriticality }))} className="w-full p-3 border rounded-xl bg-white">
                {Object.entries(CRITICALITY_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.icon} {v.label}</option>)}
              </select>
            </FormField>
            <FormField label="Poznámky"><textarea value={editForm.notes || ''} onChange={(e) => setEditForm(p => ({ ...p, notes: e.target.value }))} className="w-full p-3 border rounded-xl resize-none" rows={3} /></FormField>
            <button onClick={handleSaveEdit} disabled={isSaving} className="w-full py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2"><Save className="w-5 h-5" /> {isSaving ? 'Ukládám...' : 'Uložit'}</button>
          </div>
        </Modal>
      )}

      {/* Modal: Add Log */}
      {activeModal === 'addLog' && (
        <Modal title="Nový záznam" onClose={() => setActiveModal('none')}>
          <div className="space-y-4">
            <FormField label="Typ">
              <div className="grid grid-cols-2 gap-2">
                {LOG_TYPES.map((t) => (
                  <button key={t.value} onClick={() => setLogForm(p => ({ ...p, type: t.value as any }))}
                    className={`p-3 rounded-xl border-2 text-sm font-medium transition ${logForm.type === t.value ? 'border-blue-500 bg-blue-50' : 'border-slate-200'}`}>
                    <span className={`inline-block w-2 h-2 rounded-full ${t.color} mr-2`} />{t.label}
                  </button>
                ))}
              </div>
            </FormField>
            <FormField label="Činnost"><input type="text" value={logForm.title} onChange={(e) => setLogForm(p => ({ ...p, title: e.target.value }))} placeholder="Co se dělalo?" className="w-full p-3 border rounded-xl focus:border-blue-500 outline-none" /></FormField>
            <FormField label="Podrobnosti"><textarea value={logForm.description} onChange={(e) => setLogForm(p => ({ ...p, description: e.target.value }))} placeholder="Detaily..." className="w-full p-3 border rounded-xl resize-none" rows={3} /></FormField>
            <FormField label="Doba (min)"><input type="number" value={logForm.duration} onChange={(e) => setLogForm(p => ({ ...p, duration: e.target.value }))} placeholder="45" className="w-full p-3 border rounded-xl focus:border-blue-500 outline-none" /></FormField>
            <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
              <UserBadge name={user?.displayName || 'U'} color={roleMeta?.badgeHex || '#64748b'} size="md" />
              <div><div className="font-medium">{user?.displayName || 'Uživatel'}</div><div className="text-xs text-slate-500">{new Date().toLocaleString('cs-CZ')}</div></div>
            </div>
            <button onClick={handleAddLog} disabled={isSaving || !logForm.title.trim()} className="w-full py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 disabled:opacity-50 flex items-center justify-center gap-2"><Plus className="w-5 h-5" /> {isSaving ? 'Ukládám...' : 'Přidat'}</button>
          </div>
        </Modal>
      )}

      {/* Modal: Report Issue */}
      {activeModal === 'reportIssue' && (
        <Modal title="🚨 Nahlásit poruchu" onClose={() => setActiveModal('none')}>
          <div className="space-y-4">
            <div className="bg-red-50 border border-red-200 p-3 rounded-xl text-sm text-red-700">Změní stav stroje na "Porucha" a vytvoří úkol.</div>
            <FormField label="Název poruchy"><input type="text" value={issueForm.title} onChange={(e) => setIssueForm(p => ({ ...p, title: e.target.value }))} placeholder="Co se pokazilo?" className="w-full p-3 border rounded-xl focus:border-blue-500 outline-none" /></FormField>
            <FormField label="Popis"><textarea value={issueForm.description} onChange={(e) => setIssueForm(p => ({ ...p, description: e.target.value }))} placeholder="Detaily..." className="w-full p-3 border rounded-xl resize-none" rows={4} /></FormField>
            <FormField label="Priorita">
              <div className="grid grid-cols-4 gap-2">
                {PRIORITIES.map((p) => (
                  <button key={p.value} onClick={() => setIssueForm(pr => ({ ...pr, priority: p.value }))}
                    className={`p-2 rounded-xl border-2 text-xs font-medium transition ${issueForm.priority === p.value ? 'border-slate-800 bg-slate-100' : 'border-slate-200'}`}>
                    <span className={`inline-block w-2 h-2 rounded-full ${p.color} mr-1`} />{p.label}
                  </button>
                ))}
              </div>
            </FormField>
            <button onClick={handleReportIssue} disabled={isSaving || !issueForm.title.trim()} className="w-full py-3 bg-red-600 text-white rounded-xl font-bold hover:bg-red-700 disabled:opacity-50 flex items-center justify-center gap-2"><Send className="w-5 h-5" /> {isSaving ? 'Odesílám...' : 'Odeslat'}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// SUB-COMPONENTS
// ═══════════════════════════════════════════════════════════════════

function Modal({ title, children, onClose }: { title: string; children: React.ReactNode; onClose: () => void }) {
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end md:items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-t-3xl md:rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="sticky top-0 bg-white border-b p-4 flex items-center justify-between">
          <h2 className="text-lg font-bold">{title}</h2>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100"><X className="w-5 h-5 text-slate-500" /></button>
        </div>
        <div className="p-4">{children}</div>
      </div>
    </div>
  );
}

function FormField({ label, children }: { label: string; children: React.ReactNode }) {
  return <div><label className="block text-sm font-medium text-slate-700 mb-1">{label}</label>{children}</div>;
}

function InfoCard({ icon, label, value, highlight = false }: { icon: string; label: string; value: string; highlight?: boolean }) {
  return (
    <div className={`bg-white p-4 rounded-xl border ${highlight ? 'border-blue-200 bg-blue-50/30' : 'border-slate-100'}`}>
      <div className="flex items-center gap-2 mb-1"><span className="text-sm">{icon}</span><span className="text-xs text-slate-400 uppercase">{label}</span></div>
      <div className={`font-bold ${highlight ? 'text-blue-600' : 'text-slate-800'}`}>{value}</div>
    </div>
  );
}

function PartCard({ name, code, stock, unit, alert = false }: { name: string; code: string; stock: number; unit: string; alert?: boolean }) {
  return (
    <div className={`bg-white p-4 rounded-xl border ${alert ? 'border-red-200 bg-red-50/30' : 'border-slate-100'} flex justify-between items-center`}>
      <div><div className="font-medium text-slate-800">{name}</div><div className="text-xs text-slate-400 font-mono">{code}</div></div>
      <div className={`text-right ${alert ? 'text-red-600' : 'text-emerald-600'}`}><div className="font-bold text-lg">{stock}</div><div className="text-xs">{unit}</div></div>
    </div>
  );
}

function DocCard({ name, icon, size, count }: { name: string; icon: string; size?: string; count?: number }) {
  return (
    <button className="bg-white p-4 rounded-xl border border-slate-100 flex flex-col items-center gap-2 text-center hover:border-blue-300 hover:shadow-md transition">
      <span className="text-3xl">{icon}</span>
      <span className="text-sm font-medium text-slate-700">{name}</span>
      {size && <span className="text-xs text-slate-400">{size}</span>}
      {count && <span className="text-xs text-slate-400">{count} položek</span>}
    </button>
  );
}
