// src/pages/FleetPage.tsx
// NOMINAL CMMS — Vozový park (JCB, traktory, sekačky)

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthContext } from '../context/AuthContext';
import { Breadcrumb, StatusDot, UserBadge } from '../components/ui';
import { 
  Car, Fuel, Clock, Calendar, MapPin, 
  ChevronRight, Plus, Filter, X, Wrench,
  AlertTriangle, CheckCircle2
} from 'lucide-react';

// ═══════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════

type VehicleType = 'tractor' | 'forklift' | 'mower' | 'truck' | 'car';
type VehicleStatus = 'available' | 'in_use' | 'maintenance' | 'broken';

interface Vehicle {
  id: string;
  code: string;
  name: string;
  type: VehicleType;
  status: VehicleStatus;
  brand: string;
  model: string;
  year: number;
  licensePlate?: string;
  mthCounter?: number;
  kmCounter?: number;
  fuelLevel?: number;
  lastService?: string;
  nextService?: string;
  assignedTo?: string;
  assignedColor?: string;
  location?: string;
  buildingId?: string;  // A, B, C, D, E, L
  areaName?: string;    // Místnost (Balírna, Garáž...)
  notes?: string;
}

// Budovy pro přiřazení
const BUILDINGS_LIST = [
  { id: 'A', name: 'Administrativa' },
  { id: 'B', name: 'Spojovací krček' },
  { id: 'C', name: 'Zázemí & Vedení' },
  { id: 'D', name: 'Výrobní hala' },
  { id: 'E', name: 'Dílna & Sklad ND' },
  { id: 'L', name: 'Loupárna' },
];

// ═══════════════════════════════════════════════════════════════════
// CONFIG
// ═══════════════════════════════════════════════════════════════════

const TYPE_CONFIG: Record<VehicleType, { label: string; icon: string }> = {
  tractor: { label: 'Traktor', icon: '🚜' },
  forklift: { label: 'VZV', icon: '🏗️' },
  mower: { label: 'Sekačka', icon: '🌿' },
  truck: { label: 'Nákladní', icon: '🚛' },
  car: { label: 'Osobní', icon: '🚗' },
};

const STATUS_CONFIG: Record<VehicleStatus, { label: string; color: string }> = {
  available: { label: 'Volný', color: 'bg-emerald-500' },
  in_use: { label: 'V provozu', color: 'bg-blue-500' },
  maintenance: { label: 'Servis', color: 'bg-amber-500' },
  broken: { label: 'Porucha', color: 'bg-red-500' },
};

// ═══════════════════════════════════════════════════════════════════
// MOCK DATA
// ═══════════════════════════════════════════════════════════════════

const MOCK_VEHICLES: Vehicle[] = [
  {
    id: 'v1', code: 'JCB-01', name: 'JCB 3CX',
    type: 'tractor', status: 'available',
    brand: 'JCB', model: '3CX Eco', year: 2019,
    mthCounter: 2450, fuelLevel: 75,
    lastService: '2026-01-15', nextService: '2026-04-15',
    location: 'Garáž E',
    buildingId: 'E', areaName: 'Garáž',
  },
  {
    id: 'v2', code: 'NH-01', name: 'New Holland T5',
    type: 'tractor', status: 'in_use',
    brand: 'New Holland', model: 'T5.120', year: 2021,
    mthCounter: 1280, fuelLevel: 45,
    assignedTo: 'Filip', assignedColor: '#7c3aed',
    location: 'Loupárna - pole',
    buildingId: 'L', areaName: 'Pole',
  },
  {
    id: 'v3', code: 'SHI-01', name: 'Shibaura ST450',
    type: 'tractor', status: 'available',
    brand: 'Shibaura', model: 'ST450', year: 2018,
    mthCounter: 3100, fuelLevel: 90,
    location: 'Garáž E',
    buildingId: 'E', areaName: 'Garáž',
  },
  {
    id: 'v4', code: 'VZV-01', name: 'Vysokozdvižný vozík 1',
    type: 'forklift', status: 'in_use',
    brand: 'Linde', model: 'H25D', year: 2020,
    mthCounter: 4500,
    assignedTo: 'Petr', assignedColor: '#0ea5e9',
    location: 'Sklad D',
    buildingId: 'D', areaName: 'Balírna',
  },
  {
    id: 'v5', code: 'VZV-02', name: 'Vysokozdvižný vozík 2',
    type: 'forklift', status: 'maintenance',
    brand: 'Linde', model: 'H25D', year: 2020,
    mthCounter: 4200,
    notes: 'Výměna hydraulického oleje',
    buildingId: 'D', areaName: 'Sklad',
  },
  {
    id: 'v6', code: 'SEK-01', name: 'Sekačka Husqvarna',
    type: 'mower', status: 'available',
    brand: 'Husqvarna', model: 'Z560X', year: 2022,
    mthCounter: 320,
    location: 'Garáž E',
    buildingId: 'E', areaName: 'Garáž',
  },
  {
    id: 'v7', code: 'SEK-02', name: 'Sekačka John Deere',
    type: 'mower', status: 'broken',
    brand: 'John Deere', model: 'X590', year: 2021,
    mthCounter: 450,
    notes: 'Poškozený nůž, čeká na díl',
    buildingId: 'E', areaName: 'Garáž',
  },
  {
    id: 'v8', code: 'VZV-03', name: 'VZV Loupárna',
    type: 'forklift', status: 'available',
    brand: 'Toyota', model: '8FGF25', year: 2019,
    mthCounter: 3800,
    location: 'Loupárna - sklad',
    buildingId: 'L', areaName: 'Sklad vyloupaného obilí',
  },
];

// ═══════════════════════════════════════════════════════════════════
// COMPONENT
// ═══════════════════════════════════════════════════════════════════

export default function FleetPage() {
  const navigate = useNavigate();
  const { hasPermission } = useAuthContext();

  // State
  const [vehicles, setVehicles] = useState<Vehicle[]>(MOCK_VEHICLES);
  const [filterType, setFilterType] = useState<VehicleType | 'all'>('all');
  const [filterStatus, setFilterStatus] = useState<VehicleStatus | 'all'>('all');
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);

  // Permissions
  const canManage = hasPermission('fleet.manage');

  // ─────────────────────────────────────────────────────────────────
  // FILTERING
  // ─────────────────────────────────────────────────────────────────

  const filteredVehicles = vehicles.filter(v => {
    if (filterType !== 'all' && v.type !== filterType) return false;
    if (filterStatus !== 'all' && v.status !== filterStatus) return false;
    return true;
  });

  // Stats
  const stats = {
    total: vehicles.length,
    available: vehicles.filter(v => v.status === 'available').length,
    inUse: vehicles.filter(v => v.status === 'in_use').length,
    issues: vehicles.filter(v => ['maintenance', 'broken'].includes(v.status)).length,
  };

  // ─────────────────────────────────────────────────────────────────
  // RENDER
  // ─────────────────────────────────────────────────────────────────

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      
      {/* Header */}
      <div className="bg-white border-b px-4 py-4">
        <Breadcrumb items={[
          { label: 'Dashboard', onClick: () => navigate('/') },
          { label: 'Vozový park' },
        ]} />
        
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-slate-800">Vozový park</h1>
          {canManage && (
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg font-medium flex items-center gap-2 hover:bg-blue-700">
              <Plus className="w-5 h-5" />
              <span className="hidden sm:inline">Přidat</span>
            </button>
          )}
        </div>
      </div>

      <div className="p-4 space-y-4">
        
        {/* Stats */}
        <div className="grid grid-cols-4 gap-2">
          <StatBox 
            icon="🚗" 
            label="Celkem" 
            value={stats.total} 
            active={filterStatus === 'all'}
            onClick={() => setFilterStatus('all')}
          />
          <StatBox 
            icon="✅" 
            label="Volné" 
            value={stats.available} 
            color="text-emerald-600"
            active={filterStatus === 'available'}
            onClick={() => setFilterStatus('available')}
          />
          <StatBox 
            icon="🔄" 
            label="V provozu" 
            value={stats.inUse} 
            color="text-blue-600"
            active={filterStatus === 'in_use'}
            onClick={() => setFilterStatus('in_use')}
          />
          <StatBox 
            icon="⚠️" 
            label="Problémy" 
            value={stats.issues} 
            color="text-amber-600"
            active={filterStatus === 'maintenance' || filterStatus === 'broken'}
            onClick={() => setFilterStatus('maintenance')}
          />
        </div>

        {/* Type Filter */}
        <div className="flex gap-2 overflow-x-auto pb-1">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition ${
              filterType === 'all' ? 'bg-slate-800 text-white' : 'bg-white border text-slate-600'
            }`}
          >
            Vše
          </button>
          {Object.entries(TYPE_CONFIG).map(([key, cfg]) => (
            <button
              key={key}
              onClick={() => setFilterType(key as VehicleType)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap transition flex items-center gap-1 ${
                filterType === key ? 'bg-slate-800 text-white' : 'bg-white border text-slate-600'
              }`}
            >
              <span>{cfg.icon}</span>
              <span>{cfg.label}</span>
            </button>
          ))}
        </div>

        {/* Vehicles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {filteredVehicles.map((vehicle) => (
            <VehicleCard 
              key={vehicle.id} 
              vehicle={vehicle} 
              onClick={() => setSelectedVehicle(vehicle)} 
            />
          ))}
        </div>

        {filteredVehicles.length === 0 && (
          <div className="text-center py-12">
            <p className="text-4xl mb-4">🚗</p>
            <h3 className="text-lg font-bold text-slate-800 mb-2">Žádná vozidla</h3>
            <p className="text-slate-500">Změňte filtr</p>
          </div>
        )}
      </div>

      {/* Vehicle Detail Modal */}
      {selectedVehicle && (
        <VehicleDetailModal
          vehicle={selectedVehicle}
          onClose={() => setSelectedVehicle(null)}
          canManage={canManage}
        />
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// SUB-COMPONENTS
// ═══════════════════════════════════════════════════════════════════

function StatBox({ icon, label, value, color = 'text-slate-800', active, onClick }: {
  icon: string; label: string; value: number; color?: string; active: boolean; onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`bg-white p-3 rounded-xl border-2 text-center transition ${
        active ? 'border-blue-500' : 'border-transparent'
      }`}
    >
      <div className="text-lg mb-1">{icon}</div>
      <div className={`text-xl font-bold ${color}`}>{value}</div>
      <div className="text-xs text-slate-500">{label}</div>
    </button>
  );
}

function VehicleCard({ vehicle, onClick }: { vehicle: Vehicle; onClick: () => void }) {
  const typeCfg = TYPE_CONFIG[vehicle.type];
  const statusCfg = STATUS_CONFIG[vehicle.status];
  const building = BUILDINGS_LIST.find(b => b.id === vehicle.buildingId);

  return (
    <button
      onClick={onClick}
      className="bg-white p-4 rounded-xl border shadow-sm text-left hover:shadow-md transition flex gap-4"
    >
      {/* Icon */}
      <div className="w-14 h-14 rounded-xl bg-slate-100 flex items-center justify-center text-3xl flex-shrink-0">
        {typeCfg.icon}
      </div>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className="font-mono text-xs text-slate-400">{vehicle.code}</span>
          <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${statusCfg.color} text-white`}>
            {statusCfg.label}
          </span>
        </div>
        
        <h4 className="font-bold text-slate-800 truncate">{vehicle.name}</h4>
        
        <div className="flex items-center gap-3 mt-2 text-xs text-slate-500">
          {vehicle.mthCounter && (
            <span className="flex items-center gap-1">
              <Clock className="w-3 h-3" />
              {vehicle.mthCounter} Mth
            </span>
          )}
          {vehicle.fuelLevel !== undefined && (
            <span className="flex items-center gap-1">
              <Fuel className="w-3 h-3" />
              {vehicle.fuelLevel}%
            </span>
          )}
        </div>

        {/* Budova & Místnost */}
        {building && (
          <div className="flex items-center gap-1.5 mt-2 text-xs">
            <span className="px-1.5 py-0.5 bg-slate-100 rounded font-bold text-slate-600">
              {vehicle.buildingId}
            </span>
            <span className="text-slate-500">
              {building.name}
              {vehicle.areaName && ` • ${vehicle.areaName}`}
            </span>
          </div>
        )}

        {/* Assigned */}
        {vehicle.assignedTo && (
          <div className="flex items-center gap-2 mt-2">
            <UserBadge name={vehicle.assignedTo} color={vehicle.assignedColor || '#64748b'} size="sm" />
            <span className="text-xs text-slate-600">{vehicle.assignedTo}</span>
          </div>
        )}

        {/* Warning */}
        {vehicle.notes && vehicle.status !== 'available' && (
          <div className="mt-2 text-xs text-amber-600 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" />
            {vehicle.notes}
          </div>
        )}
      </div>

      <ChevronRight className="w-5 h-5 text-slate-300 flex-shrink-0 self-center" />
    </button>
  );
}

function VehicleDetailModal({ vehicle, onClose, canManage }: {
  vehicle: Vehicle;
  onClose: () => void;
  canManage: boolean;
}) {
  const typeCfg = TYPE_CONFIG[vehicle.type];
  const statusCfg = STATUS_CONFIG[vehicle.status];

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end md:items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-t-3xl md:rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="sticky top-0 bg-white border-b p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-3xl">{typeCfg.icon}</span>
            <div>
              <span className="font-mono text-sm text-slate-500">{vehicle.code}</span>
              <span className={`ml-2 px-2 py-0.5 rounded text-xs font-bold ${statusCfg.color} text-white`}>
                {statusCfg.label}
              </span>
            </div>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          <h2 className="text-xl font-bold text-slate-800">{vehicle.name}</h2>
          
          {/* Brand & Model */}
          <div className="bg-slate-50 p-4 rounded-xl">
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <div className="text-xs text-slate-500 mb-1">Značka</div>
                <div className="font-medium">{vehicle.brand}</div>
              </div>
              <div>
                <div className="text-xs text-slate-500 mb-1">Model</div>
                <div className="font-medium">{vehicle.model}</div>
              </div>
              <div>
                <div className="text-xs text-slate-500 mb-1">Rok</div>
                <div className="font-medium">{vehicle.year}</div>
              </div>
            </div>
          </div>

          {/* Counters */}
          <div className="grid grid-cols-2 gap-3">
            {vehicle.mthCounter !== undefined && (
              <div className="bg-blue-50 p-4 rounded-xl text-center">
                <Clock className="w-6 h-6 text-blue-500 mx-auto mb-2" />
                <div className="text-2xl font-bold text-blue-700">{vehicle.mthCounter}</div>
                <div className="text-xs text-blue-600">Motohodiny</div>
              </div>
            )}
            {vehicle.fuelLevel !== undefined && (
              <div className={`p-4 rounded-xl text-center ${
                vehicle.fuelLevel < 25 ? 'bg-red-50' : vehicle.fuelLevel < 50 ? 'bg-amber-50' : 'bg-emerald-50'
              }`}>
                <Fuel className={`w-6 h-6 mx-auto mb-2 ${
                  vehicle.fuelLevel < 25 ? 'text-red-500' : vehicle.fuelLevel < 50 ? 'text-amber-500' : 'text-emerald-500'
                }`} />
                <div className={`text-2xl font-bold ${
                  vehicle.fuelLevel < 25 ? 'text-red-700' : vehicle.fuelLevel < 50 ? 'text-amber-700' : 'text-emerald-700'
                }`}>{vehicle.fuelLevel}%</div>
                <div className="text-xs text-slate-600">Palivo</div>
              </div>
            )}
          </div>

          {/* Service info */}
          {(vehicle.lastService || vehicle.nextService) && (
            <div className="grid grid-cols-2 gap-3">
              {vehicle.lastService && (
                <div className="bg-slate-50 p-3 rounded-xl">
                  <div className="text-xs text-slate-500 mb-1">Poslední servis</div>
                  <div className="font-medium flex items-center gap-2">
                    <Wrench className="w-4 h-4 text-slate-400" />
                    {new Date(vehicle.lastService).toLocaleDateString('cs-CZ')}
                  </div>
                </div>
              )}
              {vehicle.nextService && (
                <div className="bg-slate-50 p-3 rounded-xl">
                  <div className="text-xs text-slate-500 mb-1">Příští servis</div>
                  <div className="font-medium flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-blue-500" />
                    {new Date(vehicle.nextService).toLocaleDateString('cs-CZ')}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Location */}
          {vehicle.location && (
            <div className="bg-slate-50 p-3 rounded-xl">
              <div className="text-xs text-slate-500 mb-1">Umístění</div>
              <div className="font-medium flex items-center gap-2">
                <MapPin className="w-4 h-4 text-slate-400" />
                {vehicle.location}
              </div>
            </div>
          )}

          {/* Assigned */}
          {vehicle.assignedTo && (
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-xl">
              <div className="text-sm text-blue-700">Přiřazeno:</div>
              <div className="flex items-center gap-2">
                <UserBadge name={vehicle.assignedTo} color={vehicle.assignedColor || '#64748b'} size="sm" />
                <span className="font-medium text-blue-800">{vehicle.assignedTo}</span>
              </div>
            </div>
          )}

          {/* Notes */}
          {vehicle.notes && (
            <div className="bg-amber-50 border border-amber-200 p-3 rounded-xl">
              <div className="text-xs text-amber-700 mb-1 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> Poznámka
              </div>
              <div className="text-sm text-amber-800">{vehicle.notes}</div>
            </div>
          )}

          {/* Actions */}
          {canManage && (
            <div className="flex gap-2 pt-2">
              {vehicle.status === 'available' && (
                <button className="flex-1 py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700 flex items-center justify-center gap-2">
                  <Car className="w-5 h-5" /> Přiřadit
                </button>
              )}
              {vehicle.status === 'in_use' && (
                <button className="flex-1 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 flex items-center justify-center gap-2">
                  <CheckCircle2 className="w-5 h-5" /> Vrátit
                </button>
              )}
              <button className="flex-1 py-3 bg-amber-500 text-white rounded-xl font-bold hover:bg-amber-600 flex items-center justify-center gap-2">
                <Wrench className="w-5 h-5" /> Servis
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
