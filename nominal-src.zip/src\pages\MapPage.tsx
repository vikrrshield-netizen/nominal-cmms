// src/pages/MapPage.tsx
// NOMINAL CMMS — Interaktivní mapa areálu

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Map, Building2, Factory, Warehouse, MapPin,
  ChevronRight, AlertTriangle, CheckCircle2, Clock,
  Zap, X, ArrowLeft
} from 'lucide-react';

// ═══════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════

type BuildingId = 'A' | 'B' | 'C' | 'D' | 'E' | 'L';
type BuildingStatus = 'ok' | 'warning' | 'critical';

interface Building {
  id: BuildingId;
  name: string;
  description: string;
  color: string;
  status: BuildingStatus;
  machines: number;
  issues: number;
  areas: Area[];
}

interface Area {
  id: string;
  name: string;
  floor?: string;
  machines: MachinePreview[];
}

interface MachinePreview {
  id: string;
  name: string;
  status: 'running' | 'idle' | 'maintenance' | 'broken';
  mth?: number;
}

// ═══════════════════════════════════════════════════════════════════
// MOCK DATA
// ═══════════════════════════════════════════════════════════════════

const BUILDINGS: Building[] = [
  {
    id: 'A',
    name: 'Administrativa',
    description: 'Kanceláře, zasedací místnost',
    color: 'from-blue-500 to-indigo-500',
    status: 'ok',
    machines: 0,
    issues: 0,
    areas: [
      { id: 'a1', name: 'Kanceláře', machines: [] },
      { id: 'a2', name: 'Zasedací místnost', machines: [] },
    ]
  },
  {
    id: 'B',
    name: 'Spojovací krček',
    description: 'Propojení budov A-C',
    color: 'from-slate-500 to-slate-600',
    status: 'ok',
    machines: 0,
    issues: 0,
    areas: []
  },
  {
    id: 'C',
    name: 'Zázemí & Vedení',
    description: 'Šatny, jídelna, management',
    color: 'from-purple-500 to-violet-500',
    status: 'ok',
    machines: 2,
    issues: 0,
    areas: [
      { id: 'c1', name: 'Šatny', machines: [] },
      { id: 'c2', name: 'Jídelna', machines: [
        { id: 'c-dishwasher', name: 'Myčka nádobí', status: 'running' }
      ]},
      { id: 'c3', name: 'Kanceláře vedení', machines: [] },
    ]
  },
  {
    id: 'D',
    name: 'Výrobní hala',
    description: 'Mlýn, míchárna, balení, extruze, sklady',
    color: 'from-orange-500 to-amber-500',
    status: 'warning',
    machines: 18,
    issues: 2,
    areas: [
      { 
        id: 'd1', 
        name: 'Mlýn', 
        floor: '1.NP',
        machines: [
          { id: 'd-mill1', name: 'Mlýn hlavní', status: 'running', mth: 12450 },
          { id: 'd-mill2', name: 'Mlýn sekundární', status: 'idle', mth: 8320 },
        ]
      },
      { 
        id: 'd2', 
        name: 'Míchací centrum', 
        floor: '1.NP',
        machines: [
          { id: 'd-mixer1', name: 'Míchačka 1', status: 'running', mth: 9800 },
          { id: 'd-mixer2', name: 'Míchačka 2', status: 'running', mth: 7650 },
          { id: 'd-mixer3', name: 'Míchačka 3', status: 'maintenance', mth: 11200 },
        ]
      },
      { 
        id: 'd3', 
        name: 'Balírna', 
        floor: '1.NP',
        machines: [
          { id: 'd-pack1', name: 'Balička Karel', status: 'broken', mth: 15600 },
          { id: 'd-pack2', name: 'Balička Lojza', status: 'running', mth: 12300 },
          { id: 'd-pack3', name: 'Balička U Agáty', status: 'running', mth: 9400 },
          { id: 'd-carton1', name: 'Kartónovačka 1', status: 'running', mth: 6700 },
          { id: 'd-carton2', name: 'Kartónovačka 2', status: 'idle', mth: 5200 },
        ]
      },
      { 
        id: 'd4', 
        name: 'Velín extruze', 
        floor: '2.NP',
        machines: [
          { id: 'd-ext1', name: 'Extruder 1', status: 'running', mth: 18900 },
          { id: 'd-ext2', name: 'Extruder 2', status: 'running', mth: 16400 },
        ]
      },
      { 
        id: 'd5', 
        name: 'Kotelna', 
        floor: '1.NP',
        machines: [
          { id: 'd-boiler1', name: 'Kotel 1', status: 'running', mth: 22100 },
          { id: 'd-boiler2', name: 'Kotel 2', status: 'idle', mth: 19800 },
        ]
      },
      { 
        id: 'd6', 
        name: 'Kompresorovna', 
        floor: '1.NP',
        machines: [
          { id: 'd-comp1', name: 'Kompresor 1', status: 'running', mth: 14500 },
          { id: 'd-comp2', name: 'Kompresor 2', status: 'running', mth: 12800 },
        ]
      },
      { 
        id: 'd7', 
        name: 'KGJ', 
        floor: '1.NP',
        machines: [
          { id: 'd-kgj', name: 'Kogenerační jednotka', status: 'running', mth: 8900 },
        ]
      },
    ]
  },
  {
    id: 'E',
    name: 'Dílna & Sklad ND',
    description: 'Dílna údržby, sklad, garáž',
    color: 'from-emerald-500 to-teal-500',
    status: 'ok',
    machines: 3,
    issues: 0,
    areas: [
      { id: 'e1', name: 'Dílna údržby', machines: [
        { id: 'e-lathe', name: 'Soustruh', status: 'idle', mth: 3200 },
        { id: 'e-drill', name: 'Stojanová vrtačka', status: 'idle', mth: 1800 },
      ]},
      { id: 'e2', name: 'Sklad náhradních dílů', machines: [] },
      { id: 'e3', name: 'Garáž', machines: [] },
    ]
  },
  {
    id: 'L',
    name: 'Loupárna',
    description: 'U nádraží (~1 km) — sila, loupací linka',
    color: 'from-amber-500 to-yellow-500',
    status: 'ok',
    machines: 5,
    issues: 0,
    areas: [
      { 
        id: 'l1', 
        name: 'Sila', 
        machines: [
          { id: 'l-silo1', name: 'Silo 1', status: 'running', mth: 4200 },
          { id: 'l-silo2', name: 'Silo 2', status: 'running', mth: 4150 },
          { id: 'l-silo3', name: 'Silo 3', status: 'idle', mth: 3800 },
          { id: 'l-silo4', name: 'Silo 4', status: 'running', mth: 4100 },
        ]
      },
      { 
        id: 'l2', 
        name: 'Loupací linka', 
        machines: [
          { id: 'l-line1', name: 'Loupací linka', status: 'running', mth: 6800 },
        ]
      },
      { id: 'l3', name: 'Sklad vyloupaného obilí', machines: [] },
    ]
  },
];

const STATUS_CONFIG = {
  running: { label: 'V provozu', color: 'text-emerald-400', dot: 'bg-emerald-400' },
  idle: { label: 'Nečinný', color: 'text-slate-400', dot: 'bg-slate-400' },
  maintenance: { label: 'Údržba', color: 'text-amber-400', dot: 'bg-amber-400' },
  broken: { label: 'Porucha', color: 'text-red-400', dot: 'bg-red-400 animate-pulse' },
};

const BUILDING_STATUS_CONFIG = {
  ok: { color: 'border-emerald-500/30', icon: CheckCircle2, iconColor: 'text-emerald-400' },
  warning: { color: 'border-amber-500/30', icon: AlertTriangle, iconColor: 'text-amber-400' },
  critical: { color: 'border-red-500/30', icon: AlertTriangle, iconColor: 'text-red-400' },
};

// ═══════════════════════════════════════════════════════════════════
// COMPONENT
// ═══════════════════════════════════════════════════════════════════

export default function MapPage() {
  const navigate = useNavigate();
  const [selectedBuilding, setSelectedBuilding] = useState<Building | null>(null);
  const [selectedArea, setSelectedArea] = useState<Area | null>(null);

  // Stats
  const totalMachines = BUILDINGS.reduce((sum, b) => sum + b.machines, 0);
  const totalIssues = BUILDINGS.reduce((sum, b) => sum + b.issues, 0);
  const runningMachines = BUILDINGS.flatMap(b => b.areas.flatMap(a => a.machines)).filter(m => m.status === 'running').length;

  return (
    <div className="min-h-screen bg-[#0f172a]">
      {/* Background */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-blue-500/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-emerald-500/10 rounded-full blur-[120px]" />
      </div>

      <div className="relative z-10 pb-24">
        {/* Header */}
        <header className="p-6">
          <button 
            onClick={() => navigate('/')}
            className="flex items-center gap-2 text-slate-400 hover:text-white mb-4 transition"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Dashboard</span>
          </button>
          
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 bg-gradient-to-br from-cyan-500 to-teal-500 rounded-2xl flex items-center justify-center shadow-lg shadow-cyan-500/25">
              <Map className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Mapa areálu</h1>
              <p className="text-slate-400 text-sm">NOMINAL s.r.o. — Kozlov 68</p>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-3">
            <div className="bg-white/5 backdrop-blur-xl rounded-xl p-4 border border-white/10">
              <div className="flex items-center gap-2 text-emerald-400 mb-1">
                <Zap className="w-4 h-4" />
                <span className="text-xs">V provozu</span>
              </div>
              <div className="text-2xl font-bold text-white">{runningMachines}</div>
            </div>
            <div className="bg-white/5 backdrop-blur-xl rounded-xl p-4 border border-white/10">
              <div className="flex items-center gap-2 text-slate-400 mb-1">
                <Factory className="w-4 h-4" />
                <span className="text-xs">Celkem</span>
              </div>
              <div className="text-2xl font-bold text-white">{totalMachines}</div>
            </div>
            <div className="bg-white/5 backdrop-blur-xl rounded-xl p-4 border border-white/10">
              <div className="flex items-center gap-2 text-amber-400 mb-1">
                <AlertTriangle className="w-4 h-4" />
                <span className="text-xs">Problémy</span>
              </div>
              <div className="text-2xl font-bold text-white">{totalIssues}</div>
            </div>
          </div>
        </header>

        {/* Visual Map - Hlavní areál */}
        <section className="px-6 mb-4">
          <div className="bg-white/5 backdrop-blur-xl rounded-2xl border border-white/10 p-4">
            <h2 className="text-sm font-bold text-slate-400 uppercase mb-4">Hlavní areál — Kozlov 68</h2>
            
            <div className="relative aspect-[4/3] bg-slate-800/50 rounded-xl overflow-hidden">
              <div className="absolute inset-0 grid grid-cols-4 grid-rows-3 gap-1 p-2">
                {/* Row 1 */}
                <BuildingBlock building={BUILDINGS[0]} onClick={() => setSelectedBuilding(BUILDINGS[0])} className="col-span-1" />
                <BuildingBlock building={BUILDINGS[1]} onClick={() => setSelectedBuilding(BUILDINGS[1])} className="col-span-1" />
                <BuildingBlock building={BUILDINGS[2]} onClick={() => setSelectedBuilding(BUILDINGS[2])} className="col-span-2" />
                
                {/* Row 2-3 */}
                <BuildingBlock building={BUILDINGS[3]} onClick={() => setSelectedBuilding(BUILDINGS[3])} className="col-span-3 row-span-2" />
                <BuildingBlock building={BUILDINGS[4]} onClick={() => setSelectedBuilding(BUILDINGS[4])} className="col-span-1 row-span-2" />
              </div>
            </div>
          </div>
        </section>

        {/* Loupárna - mimo areál */}
        <section className="px-6 mb-6">
          <div className="bg-amber-500/10 backdrop-blur-xl rounded-2xl border border-amber-500/20 p-4">
            <div className="flex items-center gap-2 mb-3">
              <MapPin className="w-4 h-4 text-amber-400" />
              <h2 className="text-sm font-bold text-amber-400 uppercase">Mimo areál — u nádraží (~1 km)</h2>
            </div>
            
            <button
              onClick={() => navigate('/louparna')}
              className="w-full bg-gradient-to-br from-amber-500/20 to-yellow-500/20 border border-amber-500/30 rounded-xl p-4 hover:bg-amber-500/30 transition flex items-center gap-4"
            >
              <div className="w-14 h-14 bg-gradient-to-br from-amber-500 to-yellow-500 rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-2xl font-bold text-white">L</span>
              </div>
              <div className="flex-1 text-left">
                <h3 className="font-semibold text-white">Loupárna</h3>
                <p className="text-sm text-amber-300/70">4 sila • Loupací linka • Sklad</p>
              </div>
              <ChevronRight className="w-5 h-5 text-amber-400" />
            </button>
          </div>
        </section>

        {/* Buildings List */}
        <section className="px-6">
          <h2 className="text-lg font-bold text-white mb-4">Budovy</h2>
          <div className="space-y-3">
            {BUILDINGS.map(building => {
              const statusCfg = BUILDING_STATUS_CONFIG[building.status];
              const StatusIcon = statusCfg.icon;

              return (
                <button
                  key={building.id}
                  onClick={() => setSelectedBuilding(building)}
                  className={`w-full flex items-center gap-4 p-4 bg-white/5 backdrop-blur-xl rounded-2xl border ${statusCfg.color} hover:bg-white/10 transition-all group`}
                >
                  <div className={`w-14 h-14 bg-gradient-to-br ${building.color} rounded-xl flex items-center justify-center shadow-lg flex-shrink-0`}>
                    <span className="text-2xl font-bold text-white">{building.id}</span>
                  </div>
                  <div className="flex-1 text-left min-w-0">
                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-white">{building.name}</h3>
                      <StatusIcon className={`w-4 h-4 ${statusCfg.iconColor}`} />
                    </div>
                    <p className="text-sm text-slate-400 truncate">{building.description}</p>
                    {building.machines > 0 && (
                      <div className="flex items-center gap-3 mt-1">
                        <span className="text-xs text-slate-500">{building.machines} strojů</span>
                        {building.issues > 0 && (
                          <span className="text-xs text-amber-400">{building.issues} problémů</span>
                        )}
                      </div>
                    )}
                  </div>
                  <ChevronRight className="w-5 h-5 text-slate-500 group-hover:text-white group-hover:translate-x-1 transition-all flex-shrink-0" />
                </button>
              );
            })}
          </div>
        </section>
      </div>

      {/* Building Detail Modal */}
      {selectedBuilding && !selectedArea && (
        <BuildingModal 
          building={selectedBuilding} 
          onClose={() => setSelectedBuilding(null)}
          onSelectArea={(area) => setSelectedArea(area)}
        />
      )}

      {/* Area Detail Modal */}
      {selectedArea && (
        <AreaModal 
          area={selectedArea}
          building={selectedBuilding!}
          onClose={() => setSelectedArea(null)}
          onBack={() => setSelectedArea(null)}
          onSelectMachine={(id) => navigate(`/asset/${id}`)}
        />
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// SUB-COMPONENTS
// ═══════════════════════════════════════════════════════════════════

function BuildingBlock({ building, onClick, className }: { 
  building: Building; 
  onClick: () => void; 
  className?: string;
}) {
  const statusColors = {
    ok: 'bg-emerald-500/20 border-emerald-500/30 hover:bg-emerald-500/30',
    warning: 'bg-amber-500/20 border-amber-500/30 hover:bg-amber-500/30',
    critical: 'bg-red-500/20 border-red-500/30 hover:bg-red-500/30',
  };

  return (
    <button
      onClick={onClick}
      className={`${statusColors[building.status]} border rounded-lg flex flex-col items-center justify-center transition-all hover:scale-[1.02] ${className}`}
    >
      <span className="text-xl font-bold text-white">{building.id}</span>
      <span className="text-[10px] text-slate-300 text-center px-1 truncate w-full">{building.name}</span>
    </button>
  );
}

function BuildingModal({ building, onClose, onSelectArea }: {
  building: Building;
  onClose: () => void;
  onSelectArea: (area: Area) => void;
}) {
  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-end md:items-center justify-center" onClick={onClose}>
      <div className="bg-[#1e293b] rounded-t-3xl md:rounded-3xl w-full max-w-lg max-h-[85vh] overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className={`bg-gradient-to-br ${building.color} p-6`}>
          <div className="flex items-start justify-between">
            <div>
              <div className="text-4xl font-bold text-white mb-2">Budova {building.id}</div>
              <div className="text-white/80 text-lg">{building.name}</div>
              <div className="text-white/60 text-sm">{building.description}</div>
            </div>
            <button onClick={onClose} className="p-2 rounded-xl bg-white/20 hover:bg-white/30 transition">
              <X className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-3 gap-3 p-4 border-b border-white/10">
          <div className="text-center">
            <div className="text-2xl font-bold text-white">{building.machines}</div>
            <div className="text-xs text-slate-400">Strojů</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-white">{building.areas.length}</div>
            <div className="text-xs text-slate-400">Oblastí</div>
          </div>
          <div className="text-center">
            <div className={`text-2xl font-bold ${building.issues > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>{building.issues}</div>
            <div className="text-xs text-slate-400">Problémů</div>
          </div>
        </div>

        <div className="p-4 overflow-y-auto max-h-[50vh]">
          <h3 className="text-sm font-bold text-slate-400 uppercase mb-3">Oblasti</h3>
          
          {building.areas.length === 0 ? (
            <div className="text-center py-8 text-slate-500">Žádné výrobní oblasti</div>
          ) : (
            <div className="space-y-2">
              {building.areas.map(area => {
                const runningCount = area.machines.filter(m => m.status === 'running').length;
                const issueCount = area.machines.filter(m => m.status === 'broken' || m.status === 'maintenance').length;

                return (
                  <button
                    key={area.id}
                    onClick={() => onSelectArea(area)}
                    className="w-full flex items-center gap-3 p-3 bg-white/5 rounded-xl hover:bg-white/10 transition group"
                  >
                    <div className="w-10 h-10 bg-slate-700 rounded-lg flex items-center justify-center">
                      <Factory className="w-5 h-5 text-slate-400" />
                    </div>
                    <div className="flex-1 text-left">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-white">{area.name}</span>
                        {area.floor && <span className="text-xs text-slate-500">{area.floor}</span>}
                      </div>
                      {area.machines.length > 0 && (
                        <div className="flex items-center gap-2 text-xs">
                          <span className="text-emerald-400">{runningCount} běží</span>
                          {issueCount > 0 && <span className="text-amber-400">{issueCount} problém</span>}
                        </div>
                      )}
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-white group-hover:translate-x-1 transition" />
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function AreaModal({ area, building, onClose, onBack, onSelectMachine }: {
  area: Area;
  building: Building;
  onClose: () => void;
  onBack: () => void;
  onSelectMachine: (id: string) => void;
}) {
  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-end md:items-center justify-center" onClick={onClose}>
      <div className="bg-[#1e293b] rounded-t-3xl md:rounded-3xl w-full max-w-lg max-h-[85vh] overflow-hidden" onClick={e => e.stopPropagation()}>
        <div className="p-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <button onClick={onBack} className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition">
              <ArrowLeft className="w-5 h-5 text-slate-400" />
            </button>
            <div className="flex-1">
              <div className="text-lg font-bold text-white">{area.name}</div>
              <div className="text-sm text-slate-400">Budova {building.id} {area.floor && `• ${area.floor}`}</div>
            </div>
            <button onClick={onClose} className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition">
              <X className="w-5 h-5 text-slate-400" />
            </button>
          </div>
        </div>

        <div className="p-4 overflow-y-auto max-h-[70vh]">
          <h3 className="text-sm font-bold text-slate-400 uppercase mb-3">Stroje ({area.machines.length})</h3>
          
          {area.machines.length === 0 ? (
            <div className="text-center py-8 text-slate-500">Žádné stroje v této oblasti</div>
          ) : (
            <div className="space-y-2">
              {area.machines.map(machine => {
                const statusCfg = STATUS_CONFIG[machine.status];

                return (
                  <button
                    key={machine.id}
                    onClick={() => onSelectMachine(machine.id)}
                    className="w-full flex items-center gap-3 p-4 bg-white/5 rounded-xl hover:bg-white/10 transition group"
                  >
                    <div className={`w-3 h-3 rounded-full ${statusCfg.dot}`} />
                    <div className="flex-1 text-left">
                      <div className="font-medium text-white">{machine.name}</div>
                      <div className="flex items-center gap-3 text-xs">
                        <span className={statusCfg.color}>{statusCfg.label}</span>
                        {machine.mth && (
                          <span className="text-slate-500 flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {machine.mth.toLocaleString()} Mth
                          </span>
                        )}
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-500 group-hover:text-white group-hover:translate-x-1 transition" />
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
