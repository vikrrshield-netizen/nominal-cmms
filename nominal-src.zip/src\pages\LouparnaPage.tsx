// src/pages/LouparnaPage.tsx
// NOMINAL CMMS — Loupárna (Budova L) - Sila, linka, čištění

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthContext } from '../context/AuthContext';
import { 
  ArrowLeft, Cylinder, Settings, Droplets, Wheat, 
  AlertTriangle, CheckCircle2, Edit3, Save, X,
  Thermometer, Calendar, ClipboardCheck, Plus,
  Factory, Sparkles, Truck
} from 'lucide-react';

// ═══════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════

interface Silo {
  id: string;
  name: string;
  capacity: number;        // Kapacita v tunách
  currentLevel: number;    // Aktuální stav 0-100%
  material: string;        // Surovina
  materialCode?: string;   // Kód suroviny
  lastFilled?: string;     // Poslední naplnění
  lastCleaned?: string;    // Poslední čištění
  temperature?: number;    // Teplota
  notes?: string;
}

interface ProductionStatus {
  id: string;
  name: string;
  status: 'running' | 'stopped' | 'cleaning' | 'maintenance';
  currentBatch?: string;
  lastMaintenance?: string;
  notes?: string;
}

// ═══════════════════════════════════════════════════════════════════
// MOCK DATA
// ═══════════════════════════════════════════════════════════════════

const MOCK_SILOS: Silo[] = [
  { id: 'sil-1', name: 'Silo 1', capacity: 50, currentLevel: 75, material: 'Pohanka', materialCode: 'POH-01', lastFilled: '2026-02-10', lastCleaned: '2026-01-15', temperature: 18 },
  { id: 'sil-2', name: 'Silo 2', capacity: 50, currentLevel: 30, material: 'Proso', materialCode: 'PRS-01', lastFilled: '2026-02-08', lastCleaned: '2026-01-20', temperature: 17 },
  { id: 'sil-3', name: 'Silo 3', capacity: 50, currentLevel: 90, material: 'Čirok', materialCode: 'CIR-01', lastFilled: '2026-02-14', lastCleaned: '2026-02-01', temperature: 16 },
  { id: 'sil-4', name: 'Silo 4', capacity: 50, currentLevel: 10, material: 'Prázdné', materialCode: '', lastFilled: '', lastCleaned: '2026-02-12', temperature: 15, notes: 'Připraveno k čištění' },
];

const MOCK_PRODUCTION: ProductionStatus[] = [
  { id: 'lou-1', name: 'Loupací linka', status: 'running', currentBatch: 'Pohanka LOT-2026-045', lastMaintenance: '2026-02-01' },
  { id: 'cis-1', name: 'Čistička obilí', status: 'stopped', lastMaintenance: '2026-01-28', notes: 'Čeká na surovinu' },
];

const MATERIALS = [
  'Pohanka', 'Proso', 'Čirok', 'Pšenice', 'Žito', 'Oves', 'Ječmen', 'Kukuřice', 'Rýže', 'Prázdné'
];

// ═══════════════════════════════════════════════════════════════════
// COMPONENT
// ═══════════════════════════════════════════════════════════════════

export default function LouparnaPage() {
  const navigate = useNavigate();
  const { hasPermission } = useAuthContext();
  
  const [silos, setSilos] = useState<Silo[]>(MOCK_SILOS);
  const [production, setProduction] = useState<ProductionStatus[]>(MOCK_PRODUCTION);
  const [editingSilo, setEditingSilo] = useState<string | null>(null);
  const [editForm, setEditForm] = useState<Partial<Silo>>({});
  const [showSuccess, setShowSuccess] = useState(false);

  const canEdit = hasPermission('asset.update');

  // Handlers
  const handleEditSilo = (silo: Silo) => {
    setEditingSilo(silo.id);
    setEditForm({ ...silo });
  };

  const handleSaveSilo = () => {
    if (!editingSilo) return;
    
    setSilos(prev => prev.map(s => 
      s.id === editingSilo ? { ...s, ...editForm } as Silo : s
    ));
    setEditingSilo(null);
    setEditForm({});
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 2000);
  };

  const handleCancelEdit = () => {
    setEditingSilo(null);
    setEditForm({});
  };

  const toggleProductionStatus = (id: string) => {
    setProduction(prev => prev.map(p => {
      if (p.id !== id) return p;
      const nextStatus: Record<string, ProductionStatus['status']> = {
        'running': 'stopped',
        'stopped': 'cleaning',
        'cleaning': 'running',
        'maintenance': 'stopped',
      };
      return { ...p, status: nextStatus[p.status] };
    }));
  };

  // Helpers
  const getLevelColor = (level: number) => {
    if (level >= 70) return 'bg-emerald-500';
    if (level >= 30) return 'bg-amber-500';
    return 'bg-red-500';
  };

  const getStatusConfig = (status: ProductionStatus['status']) => {
    const config = {
      running: { label: 'V provozu', color: 'bg-emerald-500', icon: Factory },
      stopped: { label: 'Zastaveno', color: 'bg-slate-500', icon: Settings },
      cleaning: { label: 'Čištění', color: 'bg-blue-500', icon: Sparkles },
      maintenance: { label: 'Údržba', color: 'bg-amber-500', icon: AlertTriangle },
    };
    return config[status];
  };

  return (
    <div className="min-h-screen bg-slate-900 text-white">
      {/* Header */}
      <header className="bg-slate-800 border-b border-slate-700 px-4 py-4">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/map')} className="p-2 hover:bg-slate-700 rounded-lg transition">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold flex items-center gap-2">
              <Wheat className="w-6 h-6 text-amber-400" />
              Loupárna (Budova L)
            </h1>
            <p className="text-sm text-slate-400">Sila • Loupací linka • Čištění obilí</p>
          </div>
        </div>
      </header>

      {/* Success Toast */}
      {showSuccess && (
        <div className="fixed top-4 right-4 bg-emerald-500 text-white px-4 py-2 rounded-lg shadow-lg flex items-center gap-2 z-50 animate-pulse">
          <CheckCircle2 className="w-5 h-5" />
          Uloženo!
        </div>
      )}

      <div className="p-4 space-y-6">
        {/* SILA */}
        <section>
          <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
            <Cylinder className="w-5 h-5 text-blue-400" />
            Sila (4x 50t)
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {silos.map(silo => (
              <div 
                key={silo.id}
                className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden"
              >
                {/* Vizuální silo */}
                <div className="relative h-40 bg-slate-700 flex items-end justify-center p-2">
                  {/* Nádoba sila */}
                  <div className="relative w-20 h-32 bg-slate-600 rounded-t-full overflow-hidden border-2 border-slate-500">
                    {/* Náplň */}
                    <div 
                      className={`absolute bottom-0 left-0 right-0 transition-all ${getLevelColor(silo.currentLevel)}`}
                      style={{ height: `${silo.currentLevel}%` }}
                    />
                    {/* Procenta */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <span className="text-2xl font-bold text-white drop-shadow-lg">
                        {silo.currentLevel}%
                      </span>
                    </div>
                  </div>
                  
                  {/* Edit button */}
                  {canEdit && (
                    <button
                      onClick={() => handleEditSilo(silo)}
                      className="absolute top-2 right-2 p-1.5 bg-slate-600 hover:bg-slate-500 rounded-lg transition"
                    >
                      <Edit3 className="w-4 h-4" />
                    </button>
                  )}
                </div>
                
                {/* Info */}
                <div className="p-3">
                  <h3 className="font-bold text-center mb-2">{silo.name}</h3>
                  
                  {editingSilo === silo.id ? (
                    // Edit mode
                    <div className="space-y-2">
                      <div>
                        <label className="text-xs text-slate-400">Stav (%)</label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={editForm.currentLevel || 0}
                          onChange={(e) => setEditForm({ ...editForm, currentLevel: Number(e.target.value) })}
                          className="w-full bg-slate-700 rounded px-2 py-1 text-sm"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-slate-400">Surovina</label>
                        <select
                          value={editForm.material || ''}
                          onChange={(e) => setEditForm({ ...editForm, material: e.target.value })}
                          className="w-full bg-slate-700 rounded px-2 py-1 text-sm"
                        >
                          {MATERIALS.map(m => (
                            <option key={m} value={m}>{m}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="text-xs text-slate-400">Poznámka</label>
                        <input
                          type="text"
                          value={editForm.notes || ''}
                          onChange={(e) => setEditForm({ ...editForm, notes: e.target.value })}
                          className="w-full bg-slate-700 rounded px-2 py-1 text-sm"
                          placeholder="Poznámka..."
                        />
                      </div>
                      <div className="flex gap-2 pt-2">
                        <button
                          onClick={handleSaveSilo}
                          className="flex-1 bg-emerald-600 hover:bg-emerald-500 py-1.5 rounded text-sm font-medium flex items-center justify-center gap-1"
                        >
                          <Save className="w-4 h-4" /> Uložit
                        </button>
                        <button
                          onClick={handleCancelEdit}
                          className="flex-1 bg-slate-600 hover:bg-slate-500 py-1.5 rounded text-sm font-medium flex items-center justify-center gap-1"
                        >
                          <X className="w-4 h-4" /> Zrušit
                        </button>
                      </div>
                    </div>
                  ) : (
                    // View mode
                    <div className="space-y-1 text-sm">
                      <div className="flex items-center gap-2 justify-center">
                        <Wheat className="w-4 h-4 text-amber-400" />
                        <span className="font-medium">{silo.material}</span>
                      </div>
                      
                      {silo.temperature && (
                        <div className="flex items-center gap-2 justify-center text-slate-400">
                          <Thermometer className="w-3 h-3" />
                          <span>{silo.temperature}°C</span>
                        </div>
                      )}
                      
                      {silo.lastFilled && (
                        <div className="text-xs text-slate-500 text-center">
                          Naplněno: {silo.lastFilled}
                        </div>
                      )}
                      
                      {silo.notes && (
                        <div className="text-xs text-amber-400 text-center mt-2">
                          ⚠️ {silo.notes}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* VÝROBNÍ STAV */}
        <section>
          <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
            <Factory className="w-5 h-5 text-emerald-400" />
            Stav výroby
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {production.map(item => {
              const config = getStatusConfig(item.status);
              const StatusIcon = config.icon;
              
              return (
                <div 
                  key={item.id}
                  className="bg-slate-800 rounded-xl border border-slate-700 p-4"
                >
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-bold text-lg">{item.name}</h3>
                    <button
                      onClick={() => toggleProductionStatus(item.id)}
                      className={`px-3 py-1.5 rounded-full text-sm font-medium flex items-center gap-2 ${config.color}`}
                    >
                      <StatusIcon className="w-4 h-4" />
                      {config.label}
                    </button>
                  </div>
                  
                  {item.currentBatch && (
                    <div className="flex items-center gap-2 text-sm text-slate-300 mb-2">
                      <Truck className="w-4 h-4 text-blue-400" />
                      <span>Aktuální šarže: <strong>{item.currentBatch}</strong></span>
                    </div>
                  )}
                  
                  {item.lastMaintenance && (
                    <div className="flex items-center gap-2 text-sm text-slate-400">
                      <Calendar className="w-4 h-4" />
                      <span>Poslední údržba: {item.lastMaintenance}</span>
                    </div>
                  )}
                  
                  {item.notes && (
                    <div className="mt-2 text-sm text-amber-400">
                      📝 {item.notes}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>

        {/* RYCHLÉ AKCE */}
        <section>
          <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
            <ClipboardCheck className="w-5 h-5 text-purple-400" />
            Rychlé akce
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <QuickAction 
              icon={<Plus className="w-5 h-5" />}
              label="Přidat kontrolu"
              color="bg-blue-600"
              onClick={() => navigate('/tasks?new=1&building=L')}
            />
            <QuickAction 
              icon={<Sparkles className="w-5 h-5" />}
              label="Zahájit čištění"
              color="bg-purple-600"
              onClick={() => {}}
            />
            <QuickAction 
              icon={<Truck className="w-5 h-5" />}
              label="Příjem suroviny"
              color="bg-emerald-600"
              onClick={() => {}}
            />
            <QuickAction 
              icon={<AlertTriangle className="w-5 h-5" />}
              label="Nahlásit problém"
              color="bg-red-600"
              onClick={() => navigate('/tasks?new=1&priority=P1&building=L')}
            />
          </div>
        </section>

        {/* KONTROLNÍ BODY BUDOVY */}
        <section>
          <h2 className="text-lg font-bold mb-4 flex items-center gap-2">
            <ClipboardCheck className="w-5 h-5 text-cyan-400" />
            Kontrolní body budovy L
          </h2>
          
          <div className="bg-slate-800 rounded-xl border border-slate-700 p-4">
            <p className="text-slate-400 text-sm mb-4">
              Kontrolní body se doplní za provozu. Kliknutím přidáte nový kontrolní bod.
            </p>
            
            <div className="space-y-2">
              <CheckItem label="Stav sil (vizuální kontrola)" checked={true} />
              <CheckItem label="Čistota podlah" checked={true} />
              <CheckItem label="Funkčnost ventilace" checked={false} />
              <CheckItem label="Těsnost spojů" checked={false} />
              <CheckItem label="Osvětlení" checked={true} />
              <CheckItem label="Hlodavci / škůdci" checked={true} />
            </div>
            
            <button className="mt-4 w-full py-2 border border-dashed border-slate-600 rounded-lg text-slate-400 hover:text-white hover:border-slate-500 transition flex items-center justify-center gap-2">
              <Plus className="w-4 h-4" />
              Přidat kontrolní bod
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// SUB-COMPONENTS
// ═══════════════════════════════════════════════════════════════════

function QuickAction({ icon, label, color, onClick }: {
  icon: React.ReactNode;
  label: string;
  color: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`${color} hover:opacity-90 p-4 rounded-xl flex flex-col items-center gap-2 transition active:scale-95`}
    >
      {icon}
      <span className="text-sm font-medium text-center">{label}</span>
    </button>
  );
}

function CheckItem({ label, checked }: { label: string; checked: boolean }) {
  const [isChecked, setIsChecked] = useState(checked);
  
  return (
    <button
      onClick={() => setIsChecked(!isChecked)}
      className="w-full flex items-center gap-3 p-2 hover:bg-slate-700 rounded-lg transition text-left"
    >
      <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition ${
        isChecked ? 'bg-emerald-500 border-emerald-500' : 'border-slate-500'
      }`}>
        {isChecked && <CheckCircle2 className="w-4 h-4" />}
      </div>
      <span className={isChecked ? 'text-slate-400 line-through' : 'text-white'}>
        {label}
      </span>
    </button>
  );
}
