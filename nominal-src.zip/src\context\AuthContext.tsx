// src/context/AuthContext.tsx
// NOMINAL CMMS — Autentizační kontext

import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import { ROLE_META, ROLE_PERMISSIONS, type UserRole, type RoleMeta, type Permission } from '../types/user';

// Alias pro Permission
export type PermissionKey = Permission;

// ═══════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════

interface User {
  id: string;
  displayName: string;
  role: UserRole;
  pin: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isKiosk: boolean;
  isReadOnly: boolean;
  roleMeta: RoleMeta | null;
  canViewSecretBox: boolean;
  login: (pin: string) => Promise<boolean>;
  logout: () => void;
  hasPermission: (permission: PermissionKey) => boolean;
}

// ═══════════════════════════════════════════════════════════════════
// MOCK USERS (PIN → User)
// ═══════════════════════════════════════════════════════════════════

const MOCK_USERS: Record<string, User> = {
  '0000': { id: 'u0', displayName: 'Kiosk Terminál', role: 'OPERATOR', pin: '0000' },
  '1111': { id: 'u1', displayName: 'Milan Novák', role: 'MAJITEL', pin: '1111' },
  '2222': { id: 'u2', displayName: 'Martina Vedoucí', role: 'VEDENI', pin: '2222' },
  '3333': { id: 'u3', displayName: 'Vilém Správce', role: 'SUPERADMIN', pin: '3333' },
  '4444': { id: 'u4', displayName: 'Pavla Drápelová', role: 'VYROBA', pin: '4444' },
  '5555': { id: 'u5', displayName: 'Zdeněk Mička', role: 'UDRZBA', pin: '5555' },
  '6666': { id: 'u6', displayName: 'Petr Volf', role: 'UDRZBA', pin: '6666' },
  '7777': { id: 'u7', displayName: 'Filip Novák', role: 'UDRZBA', pin: '7777' },
};

// ═══════════════════════════════════════════════════════════════════
// CONTEXT
// ═══════════════════════════════════════════════════════════════════

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check stored session on mount
  useEffect(() => {
    const storedPin = localStorage.getItem('nominal_pin');
    if (storedPin && MOCK_USERS[storedPin]) {
      setUser(MOCK_USERS[storedPin]);
    }
    setIsLoading(false);
  }, []);

  // Login
  const login = async (pin: string): Promise<boolean> => {
    // Simulate API delay
    await new Promise(r => setTimeout(r, 300));
    
    const foundUser = MOCK_USERS[pin];
    if (foundUser) {
      setUser(foundUser);
      localStorage.setItem('nominal_pin', pin);
      return true;
    }
    return false;
  };

  // Logout
  const logout = () => {
    setUser(null);
    localStorage.removeItem('nominal_pin');
  };

  // Derived state
  const roleMeta = user ? ROLE_META[user.role] : null;
  const isKiosk = user?.role === 'OPERATOR';
  const isReadOnly = user?.role === 'MAJITEL';
  
  // Permission check
  const hasPermission = (permission: PermissionKey): boolean => {
    if (!user) return false;
    const permissions = ROLE_PERMISSIONS[user.role];
    if (!permissions) return false;
    return permissions.includes(permission);
  };

  // canViewSecretBox závisí na permission
  const canViewSecretBox = hasPermission('secretbox.view');

  return (
    <AuthContext.Provider value={{
      user,
      isAuthenticated: !!user,
      isLoading,
      isKiosk,
      isReadOnly,
      roleMeta,
      canViewSecretBox,
      login,
      logout,
      hasPermission,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuthContext() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuthContext must be used within AuthProvider');
  }
  return context;
}
