// src/lib/firebase.ts
// NOMINAL CMMS — Firebase konfigurace

import { initializeApp } from 'firebase/app';
import { getAuth, connectAuthEmulator } from 'firebase/auth';
import { 
  getFirestore, 
  connectFirestoreEmulator,
  enableIndexedDbPersistence,
  CACHE_SIZE_UNLIMITED
} from 'firebase/firestore';
import { getStorage, connectStorageEmulator } from 'firebase/storage';

// ═══════════════════════════════════════════════════════════════════
// FIREBASE CONFIG
// ═══════════════════════════════════════════════════════════════════

// TODO: Nahradit skutečnými hodnotami z Firebase Console
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "YOUR_API_KEY",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "nominal-cmms.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "nominal-cmms",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "nominal-cmms.appspot.com",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "123456789",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:123456789:web:abc123"
};

// ═══════════════════════════════════════════════════════════════════
// INITIALIZE
// ═══════════════════════════════════════════════════════════════════

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);

// ═══════════════════════════════════════════════════════════════════
// EMULATORS (pro lokální vývoj)
// ═══════════════════════════════════════════════════════════════════

const USE_EMULATORS = import.meta.env.VITE_USE_EMULATORS === 'true';

if (USE_EMULATORS) {
  console.log('🔧 Using Firebase Emulators');
  connectAuthEmulator(auth, 'http://localhost:9099');
  connectFirestoreEmulator(db, 'localhost', 8080);
  connectStorageEmulator(storage, 'localhost', 9199);
}

// ═══════════════════════════════════════════════════════════════════
// OFFLINE PERSISTENCE
// ═══════════════════════════════════════════════════════════════════

// Povolit offline cache (kritické pro nestabilní Wi-Fi v továrně)
enableIndexedDbPersistence(db, {
  cacheSizeBytes: CACHE_SIZE_UNLIMITED
}).catch((err) => {
  if (err.code === 'failed-precondition') {
    // Více tabů otevřeno - persistence může být pouze v jednom
    console.warn('⚠️ Offline persistence failed: Multiple tabs open');
  } else if (err.code === 'unimplemented') {
    // Prohlížeč nepodporuje
    console.warn('⚠️ Offline persistence not supported in this browser');
  }
});

// ═══════════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════════

export const isOnline = () => navigator.onLine;

// Timestamp helper
export const serverTimestamp = () => {
  const { serverTimestamp } = require('firebase/firestore');
  return serverTimestamp();
};

export default app;
