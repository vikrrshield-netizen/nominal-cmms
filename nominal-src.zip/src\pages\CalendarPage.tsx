// src/pages/CalendarPage.tsx
// NOMINAL CMMS — Pondělní plánování + Týdenní plán

import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthContext } from '../context/AuthContext';
import { Breadcrumb, UserBadge } from '../components/ui';
import { 
  Calendar, ChevronLeft, ChevronRight, Lock, Unlock,
  Plus, GripVertical, Clock, Wrench, AlertTriangle,
  CheckCircle2, X, Users, Flag
} from 'lucide-react';

// ═══════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════

type TaskPriority = 'P1' | 'P2' | 'P3' | 'P4';
type DayOfWeek = 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat' | 'sun';

interface PlannedTask {
  id: string;
  title: string;
  priority: TaskPriority;
  estimatedMinutes: number;
  assigneeId?: string;
  assigneeName?: string;
  assigneeColor?: string;
  assetName?: string;
  day?: DayOfWeek;
  order: number;
}

interface WeekPlan {
  weekNumber: number;
  year: number;
  isLocked: boolean;
  lockedAt?: Date;
  lockedBy?: string;
  tasks: PlannedTask[];
}

// ═══════════════════════════════════════════════════════════════════
// CONFIG
// ═══════════════════════════════════════════════════════════════════

const DAYS: { id: DayOfWeek; label: string; short: string }[] = [
  { id: 'mon', label: 'Pondělí', short: 'Po' },
  { id: 'tue', label: 'Úterý', short: 'Út' },
  { id: 'wed', label: 'Středa', short: 'St' },
  { id: 'thu', label: 'Čtvrtek', short: 'Čt' },
  { id: 'fri', label: 'Pátek', short: 'Pá' },
  { id: 'sat', label: 'Sobota', short: 'So' },
  { id: 'sun', label: 'Neděle', short: 'Ne' },
];

const PRIORITY_CONFIG: Record<TaskPriority, { color: string; bgColor: string }> = {
  P1: { color: 'text-red-600', bgColor: 'bg-red-100' },
  P2: { color: 'text-orange-600', bgColor: 'bg-orange-100' },
  P3: { color: 'text-blue-600', bgColor: 'bg-blue-100' },
  P4: { color: 'text-slate-500', bgColor: 'bg-slate-100' },
};

// ═══════════════════════════════════════════════════════════════════
// MOCK DATA
// ═══════════════════════════════════════════════════════════════════

const BACKLOG_TASKS: PlannedTask[] = [
  { id: 'b1', title: 'Kontrola oleje KGJ', priority: 'P3', estimatedMinutes: 30, assetName: 'KGJ', order: 0 },
  { id: 'b2', title: 'Výměna filtru kompresor', priority: 'P3', estimatedMinutes: 45, assetName: 'Kompresor 1', order: 1 },
  { id: 'b3', title: 'Mazání ložisek extruder', priority: 'P3', estimatedMinutes: 60, assetName: 'Extruder 2', order: 2 },
  { id: 'b4', title: 'Kontrola bezpečnostních prvků', priority: 'P2', estimatedMinutes: 90, order: 3 },
  { id: 'b5', title: 'Instalace teplotního senzoru', priority: 'P4', estimatedMinutes: 120, order: 4 },
  { id: 'b6', title: 'Seřízení baličky', priority: 'P3', estimatedMinutes: 45, assetName: 'Balička Karel', order: 5 },
];

const INITIAL_WEEK_PLAN: WeekPlan = {
  weekNumber: 7,
  year: 2026,
  isLocked: false,
  tasks: [
    { id: 'w1', title: 'Výměna ložiska Extruder 1', priority: 'P1', estimatedMinutes: 120, assigneeName: 'Vilém', assigneeColor: '#16a34a', assetName: 'Extruder 1', day: 'mon', order: 0 },
    { id: 'w2', title: 'Preventivní prohlídka baličky', priority: 'P3', estimatedMinutes: 60, assigneeName: 'Zdeněk', assigneeColor: '#64748b', assetName: 'Balička Lojza', day: 'tue', order: 0 },
    { id: 'w3', title: 'Revize hasicích přístrojů', priority: 'P2', estimatedMinutes: 180, assigneeName: 'External', assigneeColor: '#f59e0b', day: 'wed', order: 0 },
    { id: 'w4', title: 'Kalibrace váhy', priority: 'P3', estimatedMinutes: 30, assigneeName: 'Vilém', assigneeColor: '#16a34a', day: 'thu', order: 0 },
  ],
};

// ═══════════════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════════════

const getWeekDates = (weekNum: number, year: number) => {
  // Simple calculation - in real app use date-fns or similar
  const jan1 = new Date(year, 0, 1);
  const daysOffset = (weekNum - 1) * 7;
  const monday = new Date(jan1);
  monday.setDate(jan1.getDate() + daysOffset - jan1.getDay() + 1);
  
  return DAYS.map((_, i) => {
    const date = new Date(monday);
    date.setDate(monday.getDate() + i);
    return date;
  });
};

const formatDate = (date: Date) => {
  return `${date.getDate()}.${date.getMonth() + 1}.`;
};

const getTotalMinutes = (tasks: PlannedTask[], day?: DayOfWeek) => {
  return tasks
    .filter(t => day ? t.day === day : true)
    .reduce((sum, t) => sum + t.estimatedMinutes, 0);
};

const formatMinutes = (mins: number) => {
  if (mins < 60) return `${mins} min`;
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return m > 0 ? `${h}h ${m}m` : `${h}h`;
};

// ═══════════════════════════════════════════════════════════════════
// COMPONENT
// ═══════════════════════════════════════════════════════════════════

export default function CalendarPage() {
  const navigate = useNavigate();
  const { hasPermission, user, roleMeta } = useAuthContext();

  // State
  const [weekPlan, setWeekPlan] = useState<WeekPlan>(INITIAL_WEEK_PLAN);
  const [backlog, setBacklog] = useState<PlannedTask[]>(BACKLOG_TASKS);
  const [selectedDay, setSelectedDay] = useState<DayOfWeek | null>(null);
  const [showBacklog, setShowBacklog] = useState(false);
  const [draggedTask, setDraggedTask] = useState<PlannedTask | null>(null);

  // Permissions
  const canPlan = hasPermission('wo.plan');
  const canLock = hasPermission('wo.approve');
  const isReadOnly = weekPlan.isLocked && !canLock;

  // Week dates
  const weekDates = getWeekDates(weekPlan.weekNumber, weekPlan.year);
  const isCurrentWeek = true; // Simplified

  // ─────────────────────────────────────────────────────────────────
  // ACTIONS
  // ─────────────────────────────────────────────────────────────────

  const handleLockWeek = () => {
    if (!canLock) return;
    setWeekPlan(prev => ({
      ...prev,
      isLocked: !prev.isLocked,
      lockedAt: prev.isLocked ? undefined : new Date(),
      lockedBy: prev.isLocked ? undefined : user?.displayName,
    }));
  };

  const handleAddToDay = (task: PlannedTask, day: DayOfWeek) => {
    if (isReadOnly) return;
    
    // Remove from backlog
    setBacklog(prev => prev.filter(t => t.id !== task.id));
    
    // Add to week plan
    const dayTasks = weekPlan.tasks.filter(t => t.day === day);
    const newTask: PlannedTask = {
      ...task,
      day,
      order: dayTasks.length,
    };
    
    setWeekPlan(prev => ({
      ...prev,
      tasks: [...prev.tasks, newTask],
    }));
  };

  const handleRemoveFromDay = (taskId: string) => {
    if (isReadOnly) return;
    
    const task = weekPlan.tasks.find(t => t.id === taskId);
    if (!task) return;
    
    // Remove from week plan
    setWeekPlan(prev => ({
      ...prev,
      tasks: prev.tasks.filter(t => t.id !== taskId),
    }));
    
    // Add back to backlog
    setBacklog(prev => [...prev, { ...task, day: undefined, order: prev.length }]);
  };

  const handlePrevWeek = () => {
    setWeekPlan(prev => ({
      ...prev,
      weekNumber: prev.weekNumber - 1,
      isLocked: false,
      tasks: [],
    }));
  };

  const handleNextWeek = () => {
    setWeekPlan(prev => ({
      ...prev,
      weekNumber: prev.weekNumber + 1,
      isLocked: false,
      tasks: [],
    }));
  };

  // ─────────────────────────────────────────────────────────────────
  // RENDER
  // ─────────────────────────────────────────────────────────────────

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      
      {/* Header */}
      <div className="bg-white border-b px-4 py-4">
        <Breadcrumb items={[
          { label: 'Dashboard', onClick: () => navigate('/') },
          { label: 'Plánování' },
        ]} />
        
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
            <Calendar className="w-6 h-6 text-blue-600" />
            Týdenní plán
          </h1>
          
          {canLock && (
            <button
              onClick={handleLockWeek}
              className={`px-4 py-2 rounded-lg font-medium flex items-center gap-2 transition ${
                weekPlan.isLocked 
                  ? 'bg-red-100 text-red-700 hover:bg-red-200' 
                  : 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200'
              }`}
            >
              {weekPlan.isLocked ? <Lock className="w-5 h-5" /> : <Unlock className="w-5 h-5" />}
              {weekPlan.isLocked ? 'Odemknout' : 'Uzamknout'}
            </button>
          )}
        </div>
      </div>

      <div className="p-4 space-y-4">
        
        {/* Week Navigation */}
        <div className="bg-white rounded-xl border p-4">
          <div className="flex items-center justify-between">
            <button onClick={handlePrevWeek} className="p-2 rounded-lg hover:bg-slate-100">
              <ChevronLeft className="w-5 h-5" />
            </button>
            
            <div className="text-center">
              <div className="text-lg font-bold text-slate-800">
                Týden {weekPlan.weekNumber} / {weekPlan.year}
              </div>
              <div className="text-sm text-slate-500">
                {formatDate(weekDates[0])} - {formatDate(weekDates[6])}
              </div>
              {isCurrentWeek && (
                <span className="inline-block mt-1 px-2 py-0.5 bg-blue-100 text-blue-700 text-xs font-medium rounded-full">
                  Aktuální týden
                </span>
              )}
            </div>
            
            <button onClick={handleNextWeek} className="p-2 rounded-lg hover:bg-slate-100">
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>

          {/* Lock status */}
          {weekPlan.isLocked && (
            <div className="mt-3 p-3 bg-amber-50 border border-amber-200 rounded-xl flex items-center gap-3">
              <Lock className="w-5 h-5 text-amber-600" />
              <div className="flex-1">
                <div className="text-sm font-medium text-amber-800">Plán je uzamčen</div>
                <div className="text-xs text-amber-600">
                  Uzamknul: {weekPlan.lockedBy} • {weekPlan.lockedAt?.toLocaleString('cs-CZ')}
                </div>
              </div>
            </div>
          )}

          {/* Stats */}
          <div className="mt-3 grid grid-cols-3 gap-3">
            <div className="bg-slate-50 p-3 rounded-xl text-center">
              <div className="text-xl font-bold text-slate-800">{weekPlan.tasks.length}</div>
              <div className="text-xs text-slate-500">Naplánováno</div>
            </div>
            <div className="bg-slate-50 p-3 rounded-xl text-center">
              <div className="text-xl font-bold text-slate-800">{formatMinutes(getTotalMinutes(weekPlan.tasks))}</div>
              <div className="text-xs text-slate-500">Celkem</div>
            </div>
            <div className="bg-slate-50 p-3 rounded-xl text-center">
              <div className="text-xl font-bold text-slate-800">{backlog.length}</div>
              <div className="text-xs text-slate-500">V backlogu</div>
            </div>
          </div>
        </div>

        {/* Days Grid */}
        <div className="space-y-2">
          {DAYS.slice(0, 5).map((day, i) => {
            const dayTasks = weekPlan.tasks.filter(t => t.day === day.id);
            const dayTotal = getTotalMinutes(dayTasks);
            const date = weekDates[i];
            const isToday = new Date().toDateString() === date.toDateString();

            return (
              <div 
                key={day.id}
                className={`bg-white rounded-xl border overflow-hidden ${
                  isToday ? 'ring-2 ring-blue-500' : ''
                }`}
              >
                {/* Day Header */}
                <button
                  onClick={() => setSelectedDay(selectedDay === day.id ? null : day.id)}
                  className="w-full p-3 flex items-center justify-between bg-slate-50 hover:bg-slate-100 transition"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center font-bold ${
                      isToday ? 'bg-blue-600 text-white' : 'bg-white border text-slate-600'
                    }`}>
                      {date.getDate()}
                    </div>
                    <div className="text-left">
                      <div className="font-medium text-slate-800">{day.label}</div>
                      <div className="text-xs text-slate-500">{dayTasks.length} úkolů • {formatMinutes(dayTotal)}</div>
                    </div>
                  </div>
                  
                  {/* Priority indicators */}
                  <div className="flex items-center gap-1">
                    {dayTasks.some(t => t.priority === 'P1') && (
                      <span className="w-2 h-2 rounded-full bg-red-500" />
                    )}
                    {dayTasks.some(t => t.priority === 'P2') && (
                      <span className="w-2 h-2 rounded-full bg-orange-500" />
                    )}
                    <ChevronRight className={`w-5 h-5 text-slate-400 transition ${
                      selectedDay === day.id ? 'rotate-90' : ''
                    }`} />
                  </div>
                </button>

                {/* Day Tasks */}
                {selectedDay === day.id && (
                  <div className="p-3 border-t space-y-2">
                    {dayTasks.length === 0 ? (
                      <div className="text-center py-4 text-slate-400 text-sm">
                        Žádné úkoly
                      </div>
                    ) : (
                      dayTasks.map(task => (
                        <TaskCard 
                          key={task.id} 
                          task={task} 
                          onRemove={() => handleRemoveFromDay(task.id)}
                          isLocked={isReadOnly}
                        />
                      ))
                    )}
                    
                    {/* Add from backlog */}
                    {!isReadOnly && canPlan && (
                      <button
                        onClick={() => setShowBacklog(true)}
                        className="w-full py-2 border-2 border-dashed border-slate-300 rounded-xl text-slate-400 text-sm font-medium hover:border-blue-400 hover:text-blue-500 transition flex items-center justify-center gap-2"
                      >
                        <Plus className="w-4 h-4" /> Přidat z backlogu
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Weekend (collapsed) */}
        <div className="bg-white rounded-xl border p-3 opacity-50">
          <div className="flex items-center justify-between text-slate-500">
            <span className="text-sm">Víkend (So-Ne)</span>
            <span className="text-xs">Žádné plánované úkoly</span>
          </div>
        </div>
      </div>

      {/* Backlog Modal */}
      {showBacklog && (
        <BacklogModal
          tasks={backlog}
          selectedDay={selectedDay}
          onClose={() => setShowBacklog(false)}
          onAdd={(task, day) => {
            if (day) handleAddToDay(task, day);
            setShowBacklog(false);
          }}
        />
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// SUB-COMPONENTS
// ═══════════════════════════════════════════════════════════════════

function TaskCard({ task, onRemove, isLocked }: {
  task: PlannedTask;
  onRemove: () => void;
  isLocked: boolean;
}) {
  const priorityCfg = PRIORITY_CONFIG[task.priority];

  return (
    <div className={`p-3 rounded-xl border ${priorityCfg.bgColor} flex items-start gap-3`}>
      {!isLocked && (
        <div className="text-slate-400 cursor-grab">
          <GripVertical className="w-4 h-4" />
        </div>
      )}
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className={`px-1.5 py-0.5 rounded text-xs font-bold ${priorityCfg.color} ${priorityCfg.bgColor}`}>
            {task.priority}
          </span>
          <span className="font-medium text-slate-800 truncate">{task.title}</span>
        </div>
        
        <div className="flex items-center gap-3 text-xs text-slate-500">
          <span className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {formatMinutes(task.estimatedMinutes)}
          </span>
          {task.assetName && (
            <span className="flex items-center gap-1">
              <Wrench className="w-3 h-3" />
              {task.assetName}
            </span>
          )}
        </div>
        
        {task.assigneeName && (
          <div className="flex items-center gap-2 mt-2">
            <UserBadge name={task.assigneeName} color={task.assigneeColor || '#64748b'} size="sm" />
            <span className="text-xs text-slate-600">{task.assigneeName}</span>
          </div>
        )}
      </div>

      {!isLocked && (
        <button
          onClick={onRemove}
          className="p-1 rounded hover:bg-white/50 text-slate-400 hover:text-red-500"
        >
          <X className="w-4 h-4" />
        </button>
      )}
    </div>
  );
}

function BacklogModal({ tasks, selectedDay, onClose, onAdd }: {
  tasks: PlannedTask[];
  selectedDay: DayOfWeek | null;
  onClose: () => void;
  onAdd: (task: PlannedTask, day: DayOfWeek | null) => void;
}) {
  const [targetDay, setTargetDay] = useState<DayOfWeek | null>(selectedDay);

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end md:items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-t-3xl md:rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="sticky top-0 bg-white border-b p-4 flex items-center justify-between">
          <h2 className="text-lg font-bold flex items-center gap-2">
            <Flag className="w-5 h-5 text-blue-600" />
            Backlog ({tasks.length})
          </h2>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Day selector */}
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-2">Přidat do dne:</label>
            <div className="flex gap-2 flex-wrap">
              {DAYS.slice(0, 5).map(day => (
                <button
                  key={day.id}
                  onClick={() => setTargetDay(day.id)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition ${
                    targetDay === day.id ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {day.short}
                </button>
              ))}
            </div>
          </div>

          {/* Tasks */}
          {tasks.length === 0 ? (
            <div className="text-center py-8 text-slate-500">
              <CheckCircle2 className="w-12 h-12 mx-auto mb-3 text-emerald-500" />
              <p>Backlog je prázdný!</p>
            </div>
          ) : (
            <div className="space-y-2">
              {tasks.map(task => {
                const priorityCfg = PRIORITY_CONFIG[task.priority];
                return (
                  <button
                    key={task.id}
                    onClick={() => onAdd(task, targetDay)}
                    disabled={!targetDay}
                    className="w-full p-3 rounded-xl border text-left hover:border-blue-400 hover:shadow-md transition disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`px-1.5 py-0.5 rounded text-xs font-bold ${priorityCfg.color} ${priorityCfg.bgColor}`}>
                        {task.priority}
                      </span>
                      <span className="font-medium text-slate-800">{task.title}</span>
                    </div>
                    <div className="flex items-center gap-3 text-xs text-slate-500">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatMinutes(task.estimatedMinutes)}
                      </span>
                      {task.assetName && (
                        <span className="flex items-center gap-1">
                          <Wrench className="w-3 h-3" />
                          {task.assetName}
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
