// src/pages/WastePage.tsx
// NOMINAL CMMS — Odpadové hospodářství (semafor systém)

import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthContext } from '../context/AuthContext';
import { Breadcrumb } from '../components/ui';
import { 
  Trash2, Recycle, Calendar, Bell, CheckCircle2, 
  AlertTriangle, Clock, Truck, X
} from 'lucide-react';

// ═══════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════

type WasteStatus = 'green' | 'yellow' | 'red';
type WasteType = 'municipal' | 'plastic' | 'paper' | 'glass' | 'metal' | 'bio' | 'hazardous';

interface WasteContainer {
  id: string;
  type: WasteType;
  name: string;
  location: string;
  capacity: number; // procenta
  lastEmptied?: string;
  nextPickup?: string;
  status: WasteStatus;
}

interface PickupSchedule {
  id: string;
  type: WasteType;
  dayOfWeek: number; // 0-6 (Ne-So)
  time: string;
  provider: string;
  notifyBefore: number; // hodiny
}

// ═══════════════════════════════════════════════════════════════════
// CONFIG
// ═══════════════════════════════════════════════════════════════════

const WASTE_CONFIG: Record<WasteType, { label: string; icon: string; color: string }> = {
  municipal: { label: 'Směsný', icon: '🗑️', color: 'bg-gray-500' },
  plastic: { label: 'Plast', icon: '♻️', color: 'bg-yellow-500' },
  paper: { label: 'Papír', icon: '📄', color: 'bg-blue-500' },
  glass: { label: 'Sklo', icon: '🫙', color: 'bg-green-500' },
  metal: { label: 'Kov', icon: '🔩', color: 'bg-gray-600' },
  bio: { label: 'Bio', icon: '🌿', color: 'bg-amber-600' },
  hazardous: { label: 'Nebezpečný', icon: '☢️', color: 'bg-red-600' },
};

const STATUS_CONFIG: Record<WasteStatus, { label: string; color: string; bgColor: string; icon: typeof CheckCircle2 }> = {
  green: { label: 'OK', color: 'text-emerald-600', bgColor: 'bg-emerald-100', icon: CheckCircle2 },
  yellow: { label: 'Pozor', color: 'text-amber-600', bgColor: 'bg-amber-100', icon: AlertTriangle },
  red: { label: 'Plný', color: 'text-red-600', bgColor: 'bg-red-100', icon: AlertTriangle },
};

// ═══════════════════════════════════════════════════════════════════
// MOCK DATA
// ═══════════════════════════════════════════════════════════════════

const MOCK_CONTAINERS: WasteContainer[] = [
  { id: 'c1', type: 'municipal', name: 'Kontejner směsný 1', location: 'Budova D', capacity: 85, status: 'yellow', lastEmptied: '2026-02-06', nextPickup: '2026-02-13' },
  { id: 'c2', type: 'municipal', name: 'Kontejner směsný 2', location: 'Budova C', capacity: 45, status: 'green', lastEmptied: '2026-02-06', nextPickup: '2026-02-13' },
  { id: 'c3', type: 'plastic', name: 'Kontejner plast', location: 'Budova D', capacity: 95, status: 'red', lastEmptied: '2026-01-30' },
  { id: 'c4', type: 'paper', name: 'Kontejner papír', location: 'Budova A', capacity: 60, status: 'yellow', lastEmptied: '2026-02-01' },
  { id: 'c5', type: 'bio', name: 'Kontejner bio', location: 'Budova C', capacity: 30, status: 'green', lastEmptied: '2026-02-10' },
  { id: 'c6', type: 'hazardous', name: 'Nebezpečný odpad', location: 'Sklad E', capacity: 20, status: 'green', lastEmptied: '2026-01-15' },
];

const MOCK_SCHEDULE: PickupSchedule[] = [
  { id: 's1', type: 'municipal', dayOfWeek: 4, time: '07:00', provider: 'AVE CZ', notifyBefore: 15 }, // Čtvrtek
  { id: 's2', type: 'plastic', dayOfWeek: 1, time: '08:00', provider: 'EKO-KOM', notifyBefore: 24 }, // Pondělí 2x měsíčně
  { id: 's3', type: 'paper', dayOfWeek: 1, time: '08:00', provider: 'EKO-KOM', notifyBefore: 24 },
];

// ═══════════════════════════════════════════════════════════════════
// COMPONENT
// ═══════════════════════════════════════════════════════════════════

export default function WastePage() {
  const navigate = useNavigate();
  const { hasPermission } = useAuthContext();

  // State
  const [containers, setContainers] = useState<WasteContainer[]>(MOCK_CONTAINERS);
  const [showNotification, setShowNotification] = useState(false);
  const [selectedContainer, setSelectedContainer] = useState<WasteContainer | null>(null);

  // Check for Thursday notification (municipal waste)
  useEffect(() => {
    const now = new Date();
    const isWednesday = now.getDay() === 3;
    const isAfter15 = now.getHours() >= 15;
    
    if (isWednesday && isAfter15) {
      setShowNotification(true);
    }
  }, []);

  // Stats
  const stats = {
    total: containers.length,
    green: containers.filter(c => c.status === 'green').length,
    yellow: containers.filter(c => c.status === 'yellow').length,
    red: containers.filter(c => c.status === 'red').length,
  };

  // Next pickup
  const nextPickup = MOCK_SCHEDULE.find(s => {
    const today = new Date().getDay();
    return s.dayOfWeek >= today;
  });

  // ─────────────────────────────────────────────────────────────────
  // RENDER
  // ─────────────────────────────────────────────────────────────────

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      
      {/* Notification Banner */}
      {showNotification && (
        <div className="bg-amber-500 text-white px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Bell className="w-5 h-5 animate-bounce" />
            <div>
              <div className="font-bold">Připravit popelnice!</div>
              <div className="text-sm opacity-90">Zítra svoz směsného odpadu (AVE CZ)</div>
            </div>
          </div>
          <button onClick={() => setShowNotification(false)} className="p-1 rounded hover:bg-white/20">
            <X className="w-5 h-5" />
          </button>
        </div>
      )}

      {/* Header */}
      <div className="bg-white border-b px-4 py-4">
        <Breadcrumb items={[
          { label: 'Dashboard', onClick: () => navigate('/') },
          { label: 'Odpady' },
        ]} />
        
        <div className="flex justify-between items-center">
          <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
            <Recycle className="w-6 h-6 text-emerald-600" />
            Odpadové hospodářství
          </h1>
        </div>
      </div>

      <div className="p-4 space-y-4">
        
        {/* Semafor Stats */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-emerald-50 border border-emerald-200 p-4 rounded-xl text-center">
            <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
            <div className="text-2xl font-bold text-emerald-700">{stats.green}</div>
            <div className="text-xs text-emerald-600">V pořádku</div>
          </div>
          <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl text-center">
            <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
            <div className="text-2xl font-bold text-amber-700">{stats.yellow}</div>
            <div className="text-xs text-amber-600">Pozor</div>
          </div>
          <div className="bg-red-50 border border-red-200 p-4 rounded-xl text-center">
            <AlertTriangle className="w-8 h-8 text-red-500 mx-auto mb-2 animate-pulse" />
            <div className="text-2xl font-bold text-red-700">{stats.red}</div>
            <div className="text-xs text-red-600">Plné</div>
          </div>
        </div>

        {/* Next Pickup */}
        {nextPickup && (
          <div className="bg-blue-50 border border-blue-200 p-4 rounded-xl">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                <Truck className="w-6 h-6 text-blue-600" />
              </div>
              <div className="flex-1">
                <div className="text-sm text-blue-600">Příští svoz</div>
                <div className="font-bold text-blue-800">
                  {WASTE_CONFIG[nextPickup.type].icon} {WASTE_CONFIG[nextPickup.type].label}
                </div>
                <div className="text-xs text-blue-600">
                  {['Ne', 'Po', 'Út', 'St', 'Čt', 'Pá', 'So'][nextPickup.dayOfWeek]} {nextPickup.time} • {nextPickup.provider}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Containers */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-slate-500 uppercase">Kontejnery</h3>
          
          {containers.map(container => {
            const wasteCfg = WASTE_CONFIG[container.type];
            const statusCfg = STATUS_CONFIG[container.status];
            const StatusIcon = statusCfg.icon;

            return (
              <button
                key={container.id}
                onClick={() => setSelectedContainer(container)}
                className="w-full bg-white p-4 rounded-xl border shadow-sm text-left hover:shadow-md transition"
              >
                <div className="flex items-center gap-4">
                  {/* Icon */}
                  <div className={`w-12 h-12 rounded-xl ${wasteCfg.color} flex items-center justify-center text-2xl`}>
                    {wasteCfg.icon}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-slate-800">{container.name}</div>
                    <div className="text-xs text-slate-500">{container.location}</div>
                  </div>

                  {/* Capacity Bar */}
                  <div className="w-24">
                    <div className="flex items-center justify-between mb-1">
                      <span className={`text-xs font-bold ${statusCfg.color}`}>{container.capacity}%</span>
                      <StatusIcon className={`w-4 h-4 ${statusCfg.color}`} />
                    </div>
                    <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full transition-all ${
                          container.status === 'red' ? 'bg-red-500' :
                          container.status === 'yellow' ? 'bg-amber-500' : 'bg-emerald-500'
                        }`}
                        style={{ width: `${container.capacity}%` }}
                      />
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Schedule */}
        <div className="bg-white rounded-xl border p-4">
          <h3 className="text-sm font-bold text-slate-500 uppercase mb-3 flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            Harmonogram svozů
          </h3>
          
          <div className="space-y-2">
            {MOCK_SCHEDULE.map(schedule => {
              const wasteCfg = WASTE_CONFIG[schedule.type];
              return (
                <div key={schedule.id} className="flex items-center gap-3 p-2 bg-slate-50 rounded-lg">
                  <span className="text-xl">{wasteCfg.icon}</span>
                  <div className="flex-1">
                    <div className="font-medium text-sm">{wasteCfg.label}</div>
                    <div className="text-xs text-slate-500">{schedule.provider}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium text-sm">
                      {['Ne', 'Po', 'Út', 'St', 'Čt', 'Pá', 'So'][schedule.dayOfWeek]}
                    </div>
                    <div className="text-xs text-slate-500">{schedule.time}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Container Detail Modal */}
      {selectedContainer && (
        <ContainerModal
          container={selectedContainer}
          onClose={() => setSelectedContainer(null)}
          onUpdate={(updated) => {
            setContainers(prev => prev.map(c => c.id === updated.id ? updated : c));
            setSelectedContainer(null);
          }}
        />
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// SUB-COMPONENTS
// ═══════════════════════════════════════════════════════════════════

function ContainerModal({ container, onClose, onUpdate }: {
  container: WasteContainer;
  onClose: () => void;
  onUpdate: (container: WasteContainer) => void;
}) {
  const wasteCfg = WASTE_CONFIG[container.type];
  const statusCfg = STATUS_CONFIG[container.status];

  const handleMarkEmpty = () => {
    onUpdate({
      ...container,
      capacity: 0,
      status: 'green',
      lastEmptied: new Date().toISOString().split('T')[0],
    });
  };

  const handleUpdateCapacity = (newCapacity: number) => {
    let newStatus: WasteStatus = 'green';
    if (newCapacity >= 90) newStatus = 'red';
    else if (newCapacity >= 70) newStatus = 'yellow';

    onUpdate({
      ...container,
      capacity: newCapacity,
      status: newStatus,
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end md:items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-t-3xl md:rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="sticky top-0 bg-white border-b p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-3xl">{wasteCfg.icon}</span>
            <span className={`px-2 py-1 rounded-lg text-sm font-bold ${statusCfg.bgColor} ${statusCfg.color}`}>
              {statusCfg.label}
            </span>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-slate-100">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-4">
          <h2 className="text-xl font-bold text-slate-800">{container.name}</h2>
          
          {/* Capacity */}
          <div className="bg-slate-50 p-6 rounded-xl text-center">
            <div className={`text-5xl font-bold mb-2 ${statusCfg.color}`}>{container.capacity}%</div>
            <div className="h-4 bg-slate-200 rounded-full overflow-hidden mb-4">
              <div 
                className={`h-full rounded-full transition-all ${
                  container.status === 'red' ? 'bg-red-500' :
                  container.status === 'yellow' ? 'bg-amber-500' : 'bg-emerald-500'
                }`}
                style={{ width: `${container.capacity}%` }}
              />
            </div>
            
            {/* Quick adjust */}
            <div className="flex gap-2 justify-center">
              {[0, 25, 50, 75, 100].map(val => (
                <button
                  key={val}
                  onClick={() => handleUpdateCapacity(val)}
                  className={`px-3 py-1 rounded-lg text-sm font-medium transition ${
                    container.capacity === val ? 'bg-blue-600 text-white' : 'bg-white border hover:bg-slate-100'
                  }`}
                >
                  {val}%
                </button>
              ))}
            </div>
          </div>

          {/* Info */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-slate-50 p-3 rounded-xl">
              <div className="text-xs text-slate-500 mb-1">Umístění</div>
              <div className="font-medium">{container.location}</div>
            </div>
            <div className="bg-slate-50 p-3 rounded-xl">
              <div className="text-xs text-slate-500 mb-1">Typ odpadu</div>
              <div className="font-medium">{wasteCfg.label}</div>
            </div>
            {container.lastEmptied && (
              <div className="bg-slate-50 p-3 rounded-xl">
                <div className="text-xs text-slate-500 mb-1">Poslední vývoz</div>
                <div className="font-medium">{new Date(container.lastEmptied).toLocaleDateString('cs-CZ')}</div>
              </div>
            )}
            {container.nextPickup && (
              <div className="bg-slate-50 p-3 rounded-xl">
                <div className="text-xs text-slate-500 mb-1">Příští vývoz</div>
                <div className="font-medium">{new Date(container.nextPickup).toLocaleDateString('cs-CZ')}</div>
              </div>
            )}
          </div>

          {/* Actions */}
          <button
            onClick={handleMarkEmpty}
            className="w-full py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 flex items-center justify-center gap-2"
          >
            <CheckCircle2 className="w-5 h-5" />
            Označit jako vyvezený
          </button>
        </div>
      </div>
    </div>
  );
}
