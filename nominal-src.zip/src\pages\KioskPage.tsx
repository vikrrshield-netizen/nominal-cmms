// src/pages/KioskPage.tsx
// NOMINAL CMMS — Kiosk mód pro tablet (vylepšený)

import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthContext } from '../context/AuthContext';
import { 
  AlertTriangle, Package, Lightbulb, ShieldCheck, Send, LogOut, 
  CheckCircle2, ArrowLeft, Filter, HelpCircle,
  ChevronRight, X
} from 'lucide-react';

// ═══════════════════════════════════════════════════════════════════
// TYPES
// ═══════════════════════════════════════════════════════════════════

type ViewState = 'MENU' | 'BREAKDOWN' | 'ORDER' | 'IDEA' | 'MESSAGE' | 'PREFILTER' | 'ASSISTANT';

interface QuickOption {
  id: string;
  label: string;
  icon?: string;
}

// ═══════════════════════════════════════════════════════════════════
// CONFIG - Rychlé volby
// ═══════════════════════════════════════════════════════════════════

const QUICK_BREAKDOWNS: QuickOption[] = [
  { id: 'stuck', label: 'Zaseknutý materiál', icon: '🔴' },
  { id: 'noise', label: 'Hluk / vibrace', icon: '🔊' },
  { id: 'leak', label: 'Únik oleje / kapaliny', icon: '💧' },
  { id: 'temp', label: 'Přehřívání', icon: '🌡️' },
  { id: 'electric', label: 'Elektrická závada', icon: '⚡' },
  { id: 'sensor', label: 'Chyba čidla', icon: '📡' },
  { id: 'belt', label: 'Poškozený pás / řemen', icon: '🔗' },
  { id: 'other', label: 'Jiné...', icon: '✏️' },
];

const QUICK_PARTS: QuickOption[] = [
  { id: 'brush', label: 'Kartáč', icon: '🧹' },
  { id: 'ejector', label: 'Vyražeč', icon: '🔨' },
  { id: 'blade', label: 'Nůž / čepel', icon: '🔪' },
  { id: 'bearing', label: 'Ložisko', icon: '⚙️' },
  { id: 'belt', label: 'Řemen', icon: '🔗' },
  { id: 'filter', label: 'Filtr', icon: '🌀' },
  { id: 'gloves', label: 'Rukavice', icon: '🧤' },
  { id: 'tape', label: 'Páska / lepidlo', icon: '📦' },
  { id: 'lubricant', label: 'Mazivo', icon: '🛢️' },
  { id: 'tool', label: 'Nářadí', icon: '🔧' },
  { id: 'other', label: 'Jiné...', icon: '✏️' },
];

const MACHINES_PREFILTER = [
  { id: 'ext1', label: 'Extruder 1', icon: '🔵' },
  { id: 'ext2', label: 'Extruder 2', icon: '🟢' },
  { id: 'mix1', label: 'Míchárna 1', icon: '🟠' },
  { id: 'mix2', label: 'Míchárna 2', icon: '🟡' },
];

const MACHINES_ALL = [
  { id: 'ext1', label: 'Extruder 1' },
  { id: 'ext2', label: 'Extruder 2' },
  { id: 'mix1', label: 'Míchárna 1' },
  { id: 'mix2', label: 'Míchárna 2' },
  { id: 'mix3', label: 'Míchárna 3' },
  { id: 'pack1', label: 'Balička Karel' },
  { id: 'pack2', label: 'Balička Lojza' },
  { id: 'pack3', label: 'Balička U Agáty' },
  { id: 'mill', label: 'Mlýn' },
  { id: 'comp', label: 'Kompresor' },
  { id: 'other', label: 'Jiný stroj...' },
];

const ASSISTANT_TIPS = [
  {
    title: '🔴 P1 — Havárie (okamžitě)',
    steps: [
      '1. STOP stroj (červené tlačítko)',
      '2. Nahlásit přes Kiosk → Porucha',
      '3. Zavolat údržbu: Vilém 777 123 456',
      '4. Počkat u stroje, nikoho nepouštět',
    ],
  },
  {
    title: '🟠 P2 — Vážná závada (dnes)',
    steps: [
      '1. Pokud možno dokončit sérii',
      '2. Nahlásit přes Kiosk → Porucha',
      '3. Označit stroj cedulkou',
      '4. Pokračovat na jiném stroji',
    ],
  },
  {
    title: '🟡 P3 — Běžná údržba',
    steps: [
      '1. Nahlásit přes Kiosk',
      '2. Bude naplánováno na pondělí',
      '3. Pokračovat v práci normálně',
    ],
  },
  {
    title: '🟢 P4 — Nápad / zlepšení',
    steps: [
      '1. Zapsat přes Kiosk → Nápad',
      '2. Bude projednáno na poradě',
    ],
  },
];

// ═══════════════════════════════════════════════════════════════════
// COMPONENT
// ═══════════════════════════════════════════════════════════════════

export default function KioskPage() {
  const navigate = useNavigate();
  const { logout } = useAuthContext();
  
  // State
  const [activeView, setActiveView] = useState<ViewState>('MENU');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showSuccess, setShowSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState('Odesláno!');
  
  // Form state
  const [selectedMachine, setSelectedMachine] = useState('');
  const [selectedQuickOption, setSelectedQuickOption] = useState('');
  const [customText, setCustomText] = useState('');
  const [prefilterDate, setPrefilterDate] = useState(new Date().toISOString().split('T')[0]);

  // Clock update
  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  // Reset form
  const resetForm = () => {
    setSelectedMachine('');
    setSelectedQuickOption('');
    setCustomText('');
    setPrefilterDate(new Date().toISOString().split('T')[0]);
  };

  const handleSubmit = async (message: string) => {
    console.log('Kiosk submit:', { view: activeView, message, machine: selectedMachine });
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    setSuccessMessage(activeView === 'PREFILTER' ? 'Výměna zaznamenána!' : 'Odesláno!');
    setShowSuccess(true);
    resetForm();
    setActiveView('MENU');
    setTimeout(() => setShowSuccess(false), 4000);
  };

  const handleCancel = () => {
    resetForm();
    setActiveView('MENU');
  };

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  // ═══════════════════════════════════════════════════════════════════
  // RENDERS
  // ═══════════════════════════════════════════════════════════════════

  const renderClock = () => (
    <div className="absolute top-6 left-1/2 -translate-x-1/2 text-center">
      <div className="text-5xl md:text-7xl font-mono font-bold text-white tracking-wider">
        {currentTime.toLocaleTimeString('cs-CZ', { hour: '2-digit', minute: '2-digit' })}
      </div>
      <div className="text-lg md:text-xl text-slate-400 mt-1">
        {currentTime.toLocaleDateString('cs-CZ', { weekday: 'long', day: 'numeric', month: 'long' })}
      </div>
    </div>
  );

  const renderSuccess = () => (
    <div className="fixed top-8 left-1/2 -translate-x-1/2 z-50 animate-bounce">
      <div className="bg-emerald-500 text-white px-8 py-4 rounded-2xl shadow-2xl flex items-center gap-3">
        <CheckCircle2 className="w-8 h-8" />
        <span className="text-xl md:text-2xl font-bold">{successMessage}</span>
      </div>
    </div>
  );

  const renderMenu = () => (
    <div className="w-full max-w-6xl">
      {renderClock()}
      
      <div className="mt-32 md:mt-40">
        <h1 className="text-2xl md:text-3xl font-bold text-slate-400 text-center mb-6 md:mb-8">
          Co potřebujete?
        </h1>
        
        {/* Main buttons - 2x3 grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-6 mb-6">
          {/* Porucha */}
          <MenuButton
            icon={<AlertTriangle className="w-12 h-12 md:w-16 md:h-16" />}
            label="Nahlásit poruchu"
            color="bg-red-600 hover:bg-red-500"
            onClick={() => setActiveView('BREAKDOWN')}
          />
          
          {/* Objednat díl */}
          <MenuButton
            icon={<Package className="w-12 h-12 md:w-16 md:h-16" />}
            label="Objednat díl"
            color="bg-blue-600 hover:bg-blue-500"
            onClick={() => setActiveView('ORDER')}
          />
          
          {/* Předfiltr */}
          <MenuButton
            icon={<Filter className="w-12 h-12 md:w-16 md:h-16" />}
            label="Výměna předfiltru"
            color="bg-cyan-600 hover:bg-cyan-500"
            onClick={() => setActiveView('PREFILTER')}
          />
          
          {/* Nápad */}
          <MenuButton
            icon={<Lightbulb className="w-12 h-12 md:w-16 md:h-16" />}
            label="Nápad na zlepšení"
            color="bg-emerald-600 hover:bg-emerald-500"
            onClick={() => setActiveView('IDEA')}
          />
          
          {/* Schránka důvěry */}
          <MenuButton
            icon={<ShieldCheck className="w-12 h-12 md:w-16 md:h-16" />}
            label="Schránka důvěry"
            color="bg-purple-600 hover:bg-purple-500"
            onClick={() => setActiveView('MESSAGE')}
          />
          
          {/* Asistent */}
          <MenuButton
            icon={<HelpCircle className="w-12 h-12 md:w-16 md:h-16" />}
            label="Jak postupovat?"
            color="bg-amber-600 hover:bg-amber-500"
            onClick={() => setActiveView('ASSISTANT')}
          />
        </div>
      </div>
      
      {/* Logout */}
      <button 
        onClick={handleLogout} 
        className="absolute bottom-6 left-1/2 -translate-x-1/2 text-slate-600 hover:text-white flex items-center gap-2 text-lg transition"
      >
        <LogOut className="w-5 h-5" />
        <span>Odhlásit terminál</span>
      </button>
    </div>
  );

  const renderBreakdown = () => (
    <FormWrapper title="🔴 Nahlásit poruchu" onCancel={handleCancel}>
      {/* Step 1: Select machine */}
      {!selectedMachine && (
        <div>
          <h3 className="text-xl text-slate-300 mb-4">1. Na kterém stroji?</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {MACHINES_ALL.map(machine => (
              <QuickButton
                key={machine.id}
                label={machine.label}
                selected={selectedMachine === machine.id}
                onClick={() => setSelectedMachine(machine.id)}
              />
            ))}
          </div>
        </div>
      )}

      {/* Step 2: Select problem type */}
      {selectedMachine && !selectedQuickOption && (
        <div>
          <div className="flex items-center gap-2 mb-4">
            <span className="text-emerald-400">✓</span>
            <span className="text-slate-400">{MACHINES_ALL.find(m => m.id === selectedMachine)?.label}</span>
            <button onClick={() => setSelectedMachine('')} className="text-slate-500 hover:text-white ml-2">
              <X className="w-4 h-4" />
            </button>
          </div>
          <h3 className="text-xl text-slate-300 mb-4">2. Jaký problém?</h3>
          <div className="grid grid-cols-2 gap-3">
            {QUICK_BREAKDOWNS.map(option => (
              <QuickButton
                key={option.id}
                label={`${option.icon} ${option.label}`}
                selected={selectedQuickOption === option.id}
                onClick={() => {
                  setSelectedQuickOption(option.id);
                  if (option.id !== 'other') {
                    handleSubmit(`${MACHINES_ALL.find(m => m.id === selectedMachine)?.label}: ${option.label}`);
                  }
                }}
              />
            ))}
          </div>
        </div>
      )}

      {/* Step 3: Custom text (only for "other") */}
      {selectedMachine && selectedQuickOption === 'other' && (
        <div>
          <h3 className="text-xl text-slate-300 mb-4">3. Popište problém:</h3>
          <textarea
            value={customText}
            onChange={(e) => setCustomText(e.target.value)}
            placeholder="Co se děje?"
            autoFocus
            className="w-full h-40 bg-slate-700 text-white text-xl p-4 rounded-2xl border-2 border-slate-600 focus:border-red-500 outline-none resize-none mb-4"
          />
          <button
            onClick={() => handleSubmit(`${MACHINES_ALL.find(m => m.id === selectedMachine)?.label}: ${customText}`)}
            disabled={!customText.trim()}
            className="w-full bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white py-4 rounded-2xl text-xl font-bold flex items-center justify-center gap-3"
          >
            <Send className="w-6 h-6" />
            Odeslat hlášení
          </button>
        </div>
      )}
    </FormWrapper>
  );

  const renderOrder = () => (
    <FormWrapper title="📦 Objednat díl" onCancel={handleCancel}>
      {/* Quick options */}
      {!selectedQuickOption && (
        <div>
          <h3 className="text-xl text-slate-300 mb-4">Co potřebujete?</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {QUICK_PARTS.map(option => (
              <QuickButton
                key={option.id}
                label={`${option.icon} ${option.label}`}
                selected={selectedQuickOption === option.id}
                onClick={() => {
                  setSelectedQuickOption(option.id);
                  if (option.id !== 'other') {
                    handleSubmit(`Objednávka: ${option.label}`);
                  }
                }}
              />
            ))}
          </div>
        </div>
      )}

      {/* Custom text */}
      {selectedQuickOption === 'other' && (
        <div>
          <h3 className="text-xl text-slate-300 mb-4">Upřesněte:</h3>
          <textarea
            value={customText}
            onChange={(e) => setCustomText(e.target.value)}
            placeholder="Jaký díl / nářadí potřebujete?"
            autoFocus
            className="w-full h-40 bg-slate-700 text-white text-xl p-4 rounded-2xl border-2 border-slate-600 focus:border-blue-500 outline-none resize-none mb-4"
          />
          <button
            onClick={() => handleSubmit(`Objednávka: ${customText}`)}
            disabled={!customText.trim()}
            className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white py-4 rounded-2xl text-xl font-bold flex items-center justify-center gap-3"
          >
            <Send className="w-6 h-6" />
            Odeslat objednávku
          </button>
        </div>
      )}
    </FormWrapper>
  );

  const renderPrefilter = () => (
    <FormWrapper title="🌀 Výměna předfiltru" onCancel={handleCancel}>
      {/* Select machine */}
      {!selectedMachine && (
        <div>
          <h3 className="text-xl text-slate-300 mb-4">Na kterém stroji?</h3>
          <div className="grid grid-cols-2 gap-4">
            {MACHINES_PREFILTER.map(machine => (
              <button
                key={machine.id}
                onClick={() => setSelectedMachine(machine.id)}
                className="bg-slate-700 hover:bg-slate-600 text-white p-6 rounded-2xl text-center transition active:scale-95"
              >
                <span className="text-4xl block mb-2">{machine.icon}</span>
                <span className="text-xl font-bold">{machine.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Confirm with date */}
      {selectedMachine && (
        <div>
          <div className="bg-slate-700 rounded-2xl p-6 mb-6">
            <div className="flex items-center justify-between mb-4">
              <span className="text-slate-400">Stroj:</span>
              <span className="text-white text-xl font-bold">
                {MACHINES_PREFILTER.find(m => m.id === selectedMachine)?.icon}{' '}
                {MACHINES_PREFILTER.find(m => m.id === selectedMachine)?.label}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Datum výměny:</span>
              <input
                type="date"
                value={prefilterDate}
                onChange={(e) => setPrefilterDate(e.target.value)}
                className="bg-slate-600 text-white text-xl p-2 rounded-lg border border-slate-500"
              />
            </div>
          </div>
          
          <button
            onClick={() => handleSubmit(`Výměna předfiltru: ${MACHINES_PREFILTER.find(m => m.id === selectedMachine)?.label}, datum: ${prefilterDate}`)}
            className="w-full bg-cyan-600 hover:bg-cyan-500 text-white py-5 rounded-2xl text-xl font-bold flex items-center justify-center gap-3"
          >
            <CheckCircle2 className="w-6 h-6" />
            Potvrdit výměnu
          </button>
        </div>
      )}
    </FormWrapper>
  );

  const renderIdea = () => (
    <FormWrapper title="💡 Nápad na zlepšení" onCancel={handleCancel}>
      <textarea
        value={customText}
        onChange={(e) => setCustomText(e.target.value)}
        placeholder="Váš nápad..."
        autoFocus
        className="w-full h-48 bg-slate-700 text-white text-xl p-4 rounded-2xl border-2 border-slate-600 focus:border-emerald-500 outline-none resize-none mb-4"
      />
      <button
        onClick={() => handleSubmit(`Nápad: ${customText}`)}
        disabled={!customText.trim()}
        className="w-full bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white py-4 rounded-2xl text-xl font-bold flex items-center justify-center gap-3"
      >
        <Send className="w-6 h-6" />
        Odeslat nápad
      </button>
    </FormWrapper>
  );

  const renderMessage = () => (
    <FormWrapper title="🔒 Schránka důvěry" onCancel={handleCancel}>
      <p className="text-slate-400 text-center mb-4">100% anonymní zpráva vedení</p>
      <textarea
        value={customText}
        onChange={(e) => setCustomText(e.target.value)}
        placeholder="Vaše zpráva..."
        autoFocus
        className="w-full h-48 bg-slate-700 text-white text-xl p-4 rounded-2xl border-2 border-slate-600 focus:border-purple-500 outline-none resize-none mb-4"
      />
      <button
        onClick={() => handleSubmit(`Anonymní: ${customText}`)}
        disabled={!customText.trim()}
        className="w-full bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white py-4 rounded-2xl text-xl font-bold flex items-center justify-center gap-3"
      >
        <ShieldCheck className="w-6 h-6" />
        Odeslat anonymně
      </button>
    </FormWrapper>
  );

  const renderAssistant = () => (
    <FormWrapper title="🤖 Jak postupovat při poruše?" onCancel={handleCancel}>
      <div className="space-y-4 overflow-y-auto max-h-[60vh]">
        {ASSISTANT_TIPS.map((tip, i) => (
          <div key={i} className="bg-slate-700 rounded-2xl p-4">
            <h3 className="text-xl font-bold text-white mb-3">{tip.title}</h3>
            <ul className="space-y-2">
              {tip.steps.map((step, j) => (
                <li key={j} className="text-lg text-slate-300 flex items-start gap-2">
                  <ChevronRight className="w-5 h-5 text-slate-500 flex-shrink-0 mt-0.5" />
                  {step}
                </li>
              ))}
            </ul>
          </div>
        ))}
        
        <div className="bg-amber-900/50 border border-amber-500/30 rounded-2xl p-4 mt-4">
          <h3 className="text-lg font-bold text-amber-400 mb-2">📞 Kontakty údržby:</h3>
          <p className="text-white text-lg">Vilém: <span className="font-mono">777 123 456</span></p>
          <p className="text-white text-lg">Zdeněk: <span className="font-mono">777 654 321</span></p>
        </div>
      </div>
    </FormWrapper>
  );

  // ═══════════════════════════════════════════════════════════════════
  // MAIN RENDER
  // ═══════════════════════════════════════════════════════════════════

  return (
    <div className="min-h-screen bg-slate-900 flex flex-col items-center justify-center p-4 md:p-6 relative">
      {showSuccess && renderSuccess()}
      
      {activeView === 'MENU' && renderMenu()}
      {activeView === 'BREAKDOWN' && renderBreakdown()}
      {activeView === 'ORDER' && renderOrder()}
      {activeView === 'PREFILTER' && renderPrefilter()}
      {activeView === 'IDEA' && renderIdea()}
      {activeView === 'MESSAGE' && renderMessage()}
      {activeView === 'ASSISTANT' && renderAssistant()}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
// SUB-COMPONENTS
// ═══════════════════════════════════════════════════════════════════

function MenuButton({ icon, label, color, onClick }: {
  icon: React.ReactNode;
  label: string;
  color: string;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`${color} text-white rounded-2xl md:rounded-3xl p-6 md:p-8 flex flex-col items-center justify-center transition-all shadow-2xl active:scale-95 min-h-[140px] md:min-h-[180px]`}
    >
      {icon}
      <span className="text-base md:text-xl font-bold text-center mt-3 leading-tight">{label}</span>
    </button>
  );
}

function QuickButton({ label, selected, onClick }: {
  label: string;
  selected: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`p-4 md:p-5 rounded-xl text-lg md:text-xl font-medium transition active:scale-95 ${
        selected 
          ? 'bg-blue-600 text-white' 
          : 'bg-slate-700 text-white hover:bg-slate-600'
      }`}
    >
      {label}
    </button>
  );
}

function FormWrapper({ title, onCancel, children }: {
  title: string;
  onCancel: () => void;
  children: React.ReactNode;
}) {
  return (
    <div className="w-full max-w-4xl bg-slate-800 p-6 md:p-8 rounded-3xl shadow-2xl">
      <div className="flex items-center gap-4 mb-6">
        <button 
          onClick={onCancel} 
          className="p-3 rounded-xl bg-slate-700 text-slate-400 hover:bg-slate-600 hover:text-white transition"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        <h2 className="text-2xl md:text-3xl font-bold text-white">{title}</h2>
      </div>
      {children}
    </div>
  );
}
