import { initializeApp } from 'firebase/app';
import {
  getAuth,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence,
} from 'firebase/auth';
import type { User } from 'firebase/auth';
import { getFirestore, enableIndexedDbPersistence } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

// Offline persistence
setPersistence(auth, browserLocalPersistence);
enableIndexedDbPersistence(db).catch((err) => {
  console.warn('Firestore persistence failed:', err.code);
});

// PIN to email helper
const pinToEmail = (pin: string): string => `pin_${pin}@nominal.local`;

// Auth functions
export const signInWithPin = async (pin: string): Promise<User> => {
  const email = pinToEmail(pin);
  const password = pin + '00';
  const result = await signInWithEmailAndPassword(auth, email, password);
  return result.user;
};

export const signOut = async (): Promise<void> => {
  await firebaseSignOut(auth);
};

export const onAuthChange = (callback: (user: User | null) => void) => {
  return onAuthStateChanged(auth, callback);
};

export const getUserClaims = async (): Promise<Record<string, unknown> | null> => {
  const user = auth.currentUser;
  if (!user) return null;
  const token = await user.getIdTokenResult();
  return token.claims as Record<string, unknown>;
};

export const refreshToken = async (): Promise<void> => {
  const user = auth.currentUser;
  if (user) {
    await user.getIdToken(true);
  }
};
